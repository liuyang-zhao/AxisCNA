# SpaCNA

**Spatial DNA CNV toolkit: alignment, CNV clustering, SPI lineage, plus in-package RNA / DNA–RNA multi-omics helpers.**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-Linux-lightgrey.svg)](#installation)
[![Conda](https://img.shields.io/badge/conda-spacna-green.svg)](#installation)

- **Documents:** [`INSTALL.md`](INSTALL.md)
- **Source:** https://github.com/liuyang-zhao/AXIS-DNA-seq
- **Install:** `conda install -c liuyangzhao -c conda-forge -c bioconda spacna`
- **Public data:** Human [HRA019095](https://ngdc.cncb.ac.cn/gsa-human/browse/HRA019095) · Mouse [CRA044730](https://ngdc.cncb.ac.cn/gsa/browse/CRA044730)
- **Sample barcodes (GitHub only, not in Conda):** [`data/README.md`](data/README.md)

---

## Features

- **One Conda package `spacna`** — DNA CLI + RNA helpers
- **1 Mb references shipped** — bins + GC + mappability for human / mouse
- **Generate any other bin size on demand** — `spacna gen-reference` or `spacna_gen_reference()`
- **Species parameter** — `human` / `mouse` / other
- **SPI lineage** + Pearson / Jaccard
- **Paths via args / `SPACNA_*`** — no hardcoded lab paths
- **Example figures** under [`docs/figures/`](docs/figures/)

---

## Installation

```bash
conda create -y -n spacna
conda activate spacna
conda install -y -c liuyangzhao -c conda-forge -c bioconda spacna
spacna help
```

> Upload to Anaconda.org (`liuyangzhao`) is required before public `conda install` works.

### Sample barcodes

Not in the Conda tarball. Clone GitHub and copy `data/Spatial_DNA/*.csv` into your project (see [`data/README.md`](data/README.md)).

### External software

| Resource | Purpose | Install |
|----------|---------|---------|
| Bowtie2 genome index | DNA align | [`bowtie2-build`](https://bowtie-bio.sourceforge.net/bowtie2/manual.shtml#the-bowtie2-build-indexer) |
| Cell Ranger + transcriptome | RNA count | [Cell Ranger](https://www.10xgenomics.com/support/software/cell-ranger/latest) · [refs](https://www.10xgenomics.com/support/software/cell-ranger/downloads#reference-downloads) |
| MEDICC2 (optional) | CN phylogeny | [schwarzlab-ccb/medicc2](https://github.com/schwarzlab-ccb/medicc2) — `conda install -c bioconda -c conda-forge medicc2` |
| FASTA + mappability bigWig | Custom bin GC/map | GENCODE / Ensembl · [umap](https://bismap.hoffmanlab.org/) |

```bash
export SPACNA_GENOME_HUMAN_INDEX=/path/to/GRCh38_index
export SPACNA_GENOME_MOUSE_INDEX=/path/to/GRCm39_index

# RNA (optional)
export PATH=/path/to/cellranger:$PATH
export SPACNA_CELLRANGER_HUMAN_REF=/path/to/refdata-gex-GRCh38-2024-A
export SPACNA_CELLRANGER_MOUSE_REF=/path/to/refdata-gex-GRCm39-2024-A
export SPACNA_CELLRANGER_MEM=64
export SPACNA_NUM_CORES=30
export SPACNA_RNA_DIR=/path/to/Spatial_RNA

# For gen-reference GC/map
export SPACNA_HUMAN_FASTA=/path/to/GRCh38.genome.fa
export SPACNA_HUMAN_MAP_BW=/path/to/hg38.k100.umap.bw
```

**Cell Ranger usage:**

```bash
# Inputs: $SPACNA_RNA_DIR/<id>/<id>_R1.fq.gz (cDNA), _R2.fq.gz (barcode)
spacna rna-cellranger <sample_id> human 1
```

**MEDICC2:**

```bash
conda create -y -n medicc_env && conda activate medicc_env
conda install -y -c bioconda -c conda-forge medicc2
```

---

## Bundled references & custom bin sizes

Only **1 Mb** tables ship. Other sizes are generated when you need them.

| Type | Shipped contents |
|------|------------------|
| `chrom_sizes/` | GRCh38, GRCm39 |
| `genomic_bins/` | GRCh38 / GRCm39 **1 Mb** (`.txt` + `.bed`) |
| `gc_content/` / `mappability/` | Human + mouse **1 Mb** |

```bash
spacna gen-reference --species human --bin-size 500kb --mode bins
spacna gen-reference --species human --bin-size 500kb --mode all \
  --fasta "$SPACNA_HUMAN_FASTA" --mappability-bw "$SPACNA_HUMAN_MAP_BW"
```

```r
source("scripts/R/spacna.R")
spacna_gen_reference(species = "human", bin_size = "500kb", mode = "bins")
spacna_dna_cnv(..., species = "human", bin_size = "500kb")
```

---

## Example results

![Spatial clusters](docs/figures/spatial_clusters.png)

![Genome tracks](docs/figures/genome_tracks.png)

![Silhouette](docs/figures/silhouette_scores.png)

![SPI tree](docs/figures/spi_containment_lineage_tree.png)

---

## CLI (`spacna`)

| Command | Role |
|---------|------|
| `align-dna` / `align-bulk` | Spatial / bulk DNA → 1 Mb counts |
| `gen-bins` | Rebuild shipped 1 Mb bins |
| `gen-reference` | Generate any bin size (+ optional GC/map) |
| `rna-cellranger` | Cell Ranger prep + count |
| `rscript` | Run `scripts/R/*.R` |

(`dna-align` / `bulk-align` remain as aliases.)

---

## R API (by function)

```r
repo <- system("spacna path", intern = TRUE)
setwd(repo); Sys.setenv(SPACNA_REPO_ROOT = repo)
source("scripts/R/spacna.R")
```

| Function | Role |
|----------|------|
| `spacna_dna_cnv()` | Spatial DNA CNV clustering |
| `spacna_compare_clones()` | Inter-sample Pearson / Jaccard |
| `spacna_export_medicc2()` | Export MEDICC2 input |
| `spacna_load_dna()` | Reload saved DNA results |
| `spacna_spi()` | SPI lineage analysis |
| `spacna_medicc2()` | Merged MEDICC2 pipeline |
| `spacna_rna()` | SpotClean / Seurat / optional inferCNV |
| `spacna_cnv_expr()` | CNV–expression coupling |
| `spacna_pseudotime()` | Monocle2 pseudotime |
| `spacna_gen_reference()` | Generate any bin-size reference |

```r
spacna_dna_cnv(
  expt_id = "17_1",
  base_dir = repo,
  species = "human",
  bin_size = "1Mb",
  bulk_control_path = Sys.getenv("SPACNA_BULK_CONTROL")
)

spacna_rna(
  sample_id = "1_3",
  raw_matrix_dir = file.path(Sys.getenv("SPACNA_RNA_DIR"), "1_3/raw_feature_bc_matrix"),
  out_dir = file.path("results/Spatial_RNA", "1_3")
)
```

---

## Typical workflow

```text
conda install spacna
  → set SPACNA_GENOME_* / (optional) Cell Ranger env
  → download barcodes from GitHub
  → spacna align-bulk / align-dna
  → source("scripts/R/spacna.R"); spacna_dna_cnv(...)
  → spacna_spi / spacna_medicc2 (optional)
  → spacna rna-cellranger; spacna_rna / spacna_cnv_expr
```

---

## Contact

[Issues](https://github.com/liuyang-zhao/AXIS-DNA-seq/issues)

## License

[MIT](LICENSE)
