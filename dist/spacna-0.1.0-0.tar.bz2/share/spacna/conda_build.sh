if [ -z ${CONDA_BUILD+x} ]; then
    source /s2/wangyongheng/anaconda3/conda-bld/spacna_1785741782724/work/build_env_setup.sh
fi
#!/usr/bin/env bash
# Install SpaCNA into the Conda prefix.
# Sample barcodes / paper data are NOT included (see data/README.md).
set -euo pipefail

SHARE_DIR="${PREFIX}/share/spacna"
BIN_DIR="${PREFIX}/bin"

mkdir -p "${SHARE_DIR}" "${BIN_DIR}"

copy_tree() {
    local src="$1"
    local dst="$2"
    mkdir -p "${dst}"
    tar -C "${src}" \
        --exclude='.git' \
        --exclude='conda' \
        --exclude='axis-dna-rna' \
        --exclude='results' \
        --exclude='logs' \
        --exclude='tmp' \
        --exclude='rawdata' \
        --exclude='processed' \
        --exclude='tests' \
        --exclude='__pycache__' \
        --exclude='*.pyc' \
        --exclude='Rplots.pdf' \
        --exclude='data/Spatial_DNA' \
        --exclude='data/Spatial_RNA' \
        --exclude='data/samples' \
        --exclude='data/bulk' \
        -cf - . | tar -C "${dst}" -xf -
}

copy_tree "." "${SHARE_DIR}"

mkdir -p "${SHARE_DIR}/data"
if [ -f data/README.md ]; then
    cp -f data/README.md "${SHARE_DIR}/data/README.md"
fi

install -m 0755 bin/spacna "${BIN_DIR}/spacna"
install -m 0755 bin/axis-dna "${BIN_DIR}/axis-dna"
find "${SHARE_DIR}/scripts" -type f \( -name '*.sh' -o -name '*.py' \) -exec chmod +x {} +
chmod +x "${SHARE_DIR}/bin/spacna" "${SHARE_DIR}/bin/axis-dna" 2>/dev/null || true

cat > "${SHARE_DIR}/conda_env_hint.txt" <<EOF
SpaCNA
Package root: ${SHARE_DIR}
CLI: spacna

Ships 1 Mb bins + GC/mappability only.
Generate any other bin size after downloading FASTA / bigWig:
  spacna gen-reference --species human --bin-size 500kb --mode all \\
    --fasta \$SPACNA_HUMAN_FASTA --mappability-bw \$SPACNA_HUMAN_MAP_BW

Sample barcodes: download from GitHub (data/README.md).

R: source("scripts/R/spacna.R")
  spacna_dna_cnv / spacna_spi / spacna_rna / spacna_gen_reference / spacna_medicc2
EOF
