# SpaCNA Installation and Usage

This repository hosts the full analysis pipeline. **Users install and run the software via the Conda package `spacna`.**

See also the project overview and example figures in [`README.md`](README.md).

```bash
conda install -c liuyangzhao -c conda-forge -c bioconda spacna
# RNA helpers are in the same package:
#   spacna rna-cellranger ...
#   source("scripts/R/spacna.R")  # or spacna_rna.R
```

> **Channel note:** After publishing to Anaconda.org channel `liuyangzhao`, the command above works for everyone.  
> Source: https://github.com/liuyang-zhao/SpaCNA  
> Sample barcodes are **not** in the Conda package — download from GitHub ([`data/README.md`](data/README.md)).

---

## 1. Installation

### 1.1 Install DNA core

```bash
conda create -y -n spacna
conda activate spacna

conda install -y -c liuyangzhao -c conda-forge -c bioconda spacna
```

### 1.1b RNA / Cell Ranger (same package)

```bash
spacna rna-cellranger <sample_id> human 1
```

Cell Ranger must be installed separately (see README). R entry: `source("scripts/R/spacna.R")  # or spacna_rna.R`.

### 1.2 Verify

```bash
spacna help
spacna path
# e.g. .../envs/spacna/share/spacna
```

After install:

| Item | Location |
|------|----------|
| CLI | `$CONDA_PREFIX/bin/spacna` |
| Pipeline scripts & 1 Mb references | `$CONDA_PREFIX/share/spacna/` |
| Sample barcodes | **Not included** — clone GitHub `data/` |

### 1.3 Uninstall

```bash
conda deactivate
conda env remove -n spacna
```

---

## 2. Package contents

### 2.1 CLI: `spacna`

| Command | Function |
|---------|----------|
| `spacna help` | Show help |
| `spacna path` | Print install root |
| `spacna dna-align` | Spatial DNA alignment → 1 Mb sparse counts |
| `spacna bulk-align` | Bulk DNA (normal control) → 1 Mb bin counts |
| `spacna rna-cellranger` | Spatial RNA FASTQ prep + `cellranger count` |
| `spacna gen-bins` | Rebuild shipped 1 Mb bins from chrom.sizes |
| `spacna gen-reference` | Generate any bin size (+ optional GC/map) |
| `spacna gen-gc-map` | Legacy 1 Mb GC / mappability helper |
| `spacna rscript <file.R>` | Run a bundled R script from the install root |

### 2.2 R analysis functions (under `scripts/R/` in the package)

```r
repo <- system("spacna path", intern = TRUE)
setwd(repo)
Sys.setenv(SPACNA_REPO_ROOT = repo)

source("scripts/R/human_spatial_dna_analysis.R")
source("scripts/R/mouse_spatial_dna_analysis.R")
source("scripts/R/spatial_dna_analysis.R")
source("scripts/R/medicc2_evolution.R")
source("scripts/R/spi_lineage_analysis.R")
# RNA / multi-omics → source("scripts/R/spacna.R")  # or spacna_rna.R
```

| Function / script | File | Role |
|-------------------|------|------|
| `spacna_dna_cnv()` | `spatial_dna_analysis.R` | Unified spatial CNV (`species`, `bin_size`) |
| `run_unified_spatial_dna()` / `run_slide_dna_mouse()` | same (aliases) | Backward-compatible wrappers |
| `spacna_compare_clones()` | same | Pearson / Spearman / Jaccard |
| `spacna_export_medicc2()` | same | Export MEDICC2 input table |
| `spacna_spi()` | `spi_lineage_analysis.R` | SPI, fate, differential CNA, lineage tree |
| `plot_containment_lineage_tree.py` | `scripts/lineage/` | SPI containment lineage tree |
| `spacna_rna.R` | `scripts/R/` | SpotClean/Seurat/inferCNV, coupling, pseudotime |
| `spacna rna-cellranger` | CLI | Cell Ranger prep + count |
| `spacna gen-reference` | CLI | Generate any bin size (+ optional GC/map) |
| `spacna_gen_reference()` | `generate_reference.R` | Same as `gen-reference`, callable from R |

### 2.3 SPI definition

```text
SPI(pre → post) = |E_pre ∩ E_post| / |E_pre|
```

Fraction of a pre-chemo clone’s segment-level CNA events retained in a post-chemo clone (**directional**). Symmetric Pearson / Jaccard are provided by `spacna_compare_clones()` for overall similarity; they do not replace SPI for ancestry inference.

---

## 3. Required environment variables

Conda installs the software; **genome indexes and Cell Ranger references** must be provided locally:

```bash
conda activate spacna

# DNA alignment (required)
export SPACNA_GENOME_HUMAN_INDEX=/path/to/GRCh38_index
export SPACNA_GENOME_MOUSE_INDEX=/path/to/GRCm39_index

# Spatial RNA (required only for Cell Ranger)
export SPACNA_CELLRANGER_HUMAN_REF=/path/to/refdata-gex-GRCh38-2024-A
export SPACNA_CELLRANGER_MOUSE_REF=/path/to/refdata-gex-GRCm39-2024-A
```

| Variable | Meaning | Default |
|----------|---------|---------|
| `SPACNA_REPO_ROOT` | Software root | Auto (`spacna path`) |
| `SPACNA_NUM_CORES` | Parallel jobs / Cell Ranger cores | `30` |
| `SPACNA_BULK_DIR` | Bulk data directory | `$SPACNA_REPO_ROOT/data/bulk` |
| `SPACNA_RNA_DIR` | Spatial RNA data directory | `$SPACNA_REPO_ROOT/data/Spatial_RNA` |
| `SPACNA_GENOME_HUMAN_INDEX` | Human Bowtie2 index prefix | none (required) |
| `SPACNA_GENOME_MOUSE_INDEX` | Mouse Bowtie2 index prefix | none (required) |
| `SPACNA_CELLRANGER_HUMAN_REF` | Human Cell Ranger transcriptome | none |
| `SPACNA_CELLRANGER_MOUSE_REF` | Mouse Cell Ranger transcriptome | none |
| `SPACNA_CELLRANGER_BIN` | `cellranger` executable | `cellranger` |
| `SPACNA_CELLRANGER_MEM` | Cell Ranger memory (GB) | `64` |

**Not in the Conda package:** Cell Ranger, MEDICC2, and Bowtie2 genome index files. Install links: see [README.md](README.md#external-software--resources-install-yourself).

---

## 4. Quick examples

### 4.1 Spatial DNA alignment

```bash
# Prepare:
#   <project>/rawdata/<run>_R1.fq.gz
#   <project>/rawdata/<run>_R2.fq.gz
#   <project>/processed/<run>.spatial_barcodes_location.csv

spacna dna-align /path/to/project 17_1 human 1
```

| Argument | Meaning |
|----------|---------|
| `project_dir` | Project directory |
| `run_id` | Sample name (must match file names) |
| `species` | `human` or `mouse` |
| `start_step` | Resume from step 1–12 (default `1`) |

Output: `<project>/results/<run>.sparse_counts_1Mb.txt`

### 4.2 Bulk normal control

```bash
# Place FASTQs under data/bulk/ or SPACNA_BULK_DIR:
#   <run>_R1.fq.gz  <run>_R2.fq.gz

spacna bulk-align normal_sample human 1
```

### 4.3 Spatial RNA (Cell Ranger)

```bash
# data/Spatial_RNA/<id>/<id>_R1.fq.gz  (cDNA)
# data/Spatial_RNA/<id>/<id>_R2.fq.gz  (barcode)

spacna rna-cellranger 1_3 human 1
```

Downstream R uses **`raw_feature_bc_matrix/`** (`barcodes.tsv.gz`, `features.tsv.gz`, `matrix.mtx.gz`).

### 4.4 Human CNV clustering (R)

```r
repo <- system("spacna path", intern = TRUE)
setwd(repo)
source("scripts/R/human_spatial_dna_analysis.R")

res <- run_unified_spatial_dna(
  expt_id = "17_1",
  base_dir = repo,
  resolution = 80,
  bulk_control_path = file.path(repo, "data/bulk/normal_1Mb_total_reads.txt"),
  bins_path = file.path(repo, "reference/genomic_bins/GRCh38_1Mb_bins.txt"),
  gc_path = file.path(repo, "reference/gc_content/GRCh38_1Mb_gc.txt"),
  map_path = file.path(repo, "reference/mappability/hg38_1Mb_map.txt"),
  k_clusters = NULL,
  max_k_silhouette = 6,
  rna_loc_path = NULL
)
```

| Parameter | Meaning |
|-----------|---------|
| `expt_id` | Sample ID |
| `base_dir` | Install root (`spacna path`) |
| `resolution` | Spatial plot grid (default 80) |
| `bulk_control_path` | Normal bulk 1 Mb counts |
| `k_clusters` | Manual *k*; `NULL` → silhouette auto-*k* |
| `max_k_silhouette` | Max *k* for auto selection |
| `rna_loc_path` | Optional RNA position file |

### 4.5 Pearson / Jaccard

```r
spacna_compare_clones("sample_A", "sample_B", base_dir = repo, gain_loss_cutoff = 0.25)
```

### 4.6 SPI lineage analysis

```r
source("scripts/R/spi_lineage_analysis.R")

spacna_spi(
  cn_table_path = "results/MEDICC2_Input/Chemo_Evolution_medicc2_input.tsv",
  clone_groups = list(
    pre  = c("17_1_C1", "19_1_C1"),
    post = c("19_2_C1", "20_2_C1")
  ),
  out_dir = "results/SPI_lineage",
  min_spi = 0.6,
  private_emergent_thr = 0.35,
  abs_delta_thr = 0.5,
  q_thr = 0.05,
  plot_lineage_tree = TRUE,
  lineage_tau = 0.8,
  divider_label = "treatment"
)
```

| Parameter | Meaning |
|-----------|---------|
| `min_spi` | SPI cutoff for identifiable ancestor |
| `private_emergent_thr` | Private-event fraction → emergent |
| `abs_delta_thr` / `q_thr` | Differential region calling thresholds |
| `plot_lineage_tree` | Write containment tables and plot lineage tree |
| `lineage_tau` | Containment threshold for tree edges |
| `divider_label` | Vertical divider label (e.g. `CAPOX`) |

Tree figure (also written by the runner):

```text
results/SPI_lineage/07_containment_lineage_tree_by_pair_events.png
```

Standalone replot:

```bash
python scripts/lineage/plot_containment_lineage_tree.py \
  --out-dir results/SPI_lineage \
  --post-arm-modes pair_events \
  --divider-label CAPOX \
  --tau 0.8
```

---

## 5. Recommended workflow

1. `conda install ... spacna` and `conda activate spacna`
2. Set `AXIS_GENOME_*_INDEX` (and optional Cell Ranger variables)
3. `spacna bulk-align` → normal control
4. `spacna dna-align` → sparse counts
5. R: `run_unified_spatial_dna` / `run_slide_dna_mouse`
6. (Optional) `spacna_export_medicc2` → medicc2 → `spacna_spi`
7. (Optional) `spacna rna-cellranger` → RNA–DNA registration

Published barcode list: `data/samples/sample_manifest.tsv` in the install tree (or this repository).

---

## 6. FAQ

**Q: `PackagesNotFoundError: spacna`?**  
A: Check channels: `-c liuyangzhao -c conda-forge -c bioconda`. If the package is not yet on anaconda.org, the maintainer must publish it first (see below).

**Q: Missing genome index?**  
A: Set `SPACNA_GENOME_HUMAN_INDEX` or `SPACNA_GENOME_MOUSE_INDEX`.

**Q: Cell Ranger not found?**  
A: Not shipped in the package. Install separately and set `AXIS_CELLRANGER_*_REF`.

**Q: How to install MEDICC2?**  
A: Recommended (from [schwarzlab-ccb/medicc2](https://github.com/schwarzlab-ccb/medicc2)):

```bash
conda create -y -n medicc_env
conda activate medicc_env
conda install -y -c bioconda -c conda-forge medicc2
```

**Q: Optional R packages (Seurat, etc.) missing?**  
A: `conda install -c conda-forge -c bioconda r-seurat r-complexheatmap`

---

## 7. Maintainers: publish to Anaconda.org (once)

For users to run `conda install -c liuyangzhao spacna`, upload the package:

```bash
# 1. Anaconda.org account: liuyangzhao
# 2. Install client and log in
conda install -y anaconda-client
anaconda login

# 3. Build (from repository root)
conda build -c conda-forge -c bioconda conda/recipe

# 4. Upload
anaconda upload -u liuyangzhao \
  "$(conda build conda/recipe --output)"
# or: anaconda upload -u liuyangzhao conda/dist/spacna-*.tar.bz2
```

After upload:

```bash
conda install -c liuyangzhao -c conda-forge -c bioconda spacna
```

Package page: `https://anaconda.org/liuyangzhao/spacna`  
GitHub: `https://github.com/liuyang-zhao/SpaCNA`

---

## 8. License

MIT — see [LICENSE](LICENSE).
