# Sample / paper-specific data (NOT shipped in the Conda package)
#
# Download from the GitHub repository:
#   https://github.com/liuyang-zhao/AXIS-DNA-seq
#
# Typical paths after clone:
#   data/Spatial_DNA/<sample_id>.spatial_barcodes_location.csv
#   data/Spatial_RNA/<sample_id>/position_<sample_id>.txt
#   data/samples/sample_manifest.tsv
#
# Manifest of published accessions:
#   Human DNA/RNA: HRA019095
#   Mouse DNA:     CRA044730
#
# After `conda install spacna`, place downloaded barcode CSVs under your
# analysis project's `data/Spatial_DNA/` (or set paths explicitly in R).
#
# The Conda package only ships small 1 Mb reference tables under `reference/`.
