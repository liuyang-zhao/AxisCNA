# SpaCNA RNA / DNA–RNA multi-omics entry.
#
# Usage:
#   source("scripts/R/spacna.R")   # preferred (loads everything)
#   # or:
#   source("scripts/R/spacna_rna.R")
#   spacna_rna(...)
#   spacna_cnv_expr(...)
#   spacna_pseudotime(...)
#   # CLI: spacna rna-cellranger / spacna rscript plot_cnv_expr_publication.R

.spacna_r_dir <- {
  candidates <- c(
    file.path(Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = "")), "scripts/R"),
    "scripts/R",
    "."
  )
  hit <- candidates[file.exists(file.path(candidates, "spatial_rna_analysis.R"))][1]
  if (is.na(hit)) stop("Cannot find scripts/R; set SPACNA_REPO_ROOT")
  hit
}

source(file.path(.spacna_r_dir, "spatial_rna_helpers.R"))
source(file.path(.spacna_r_dir, "spatial_rna_analysis.R"))
source(file.path(.spacna_r_dir, "cnv_expr_coupling.R"))
source(file.path(.spacna_r_dir, "rna_pseudotime.R"))

message(
  "[spacna_rna] Loaded: spacna_rna, spacna_cnv_expr, spacna_pseudotime. ",
  "CLI: spacna rna-cellranger / spacna rscript ..."
)
