#!/usr/bin/env Rscript
# Publication CNV–expression figures (parameterized; no hardcoded paths).
#
# Expects outputs of run_cnv_expr_coupling() in --out-dir, or pass file paths.
#
# Example:
#   Rscript plot_cnv_expr_publication.R \
#     --out-dir results/multiomics/cnv_exp \
#     --cnv-csv path/to/clone_cnv_for_expr_integration.csv

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(scales)
})

parse_args <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  get <- function(flag, default = NULL) {
    i <- match(flag, args)
    if (is.na(i) || i >= length(args)) return(default)
    args[[i + 1]]
  }
  out_dir <- get("--out-dir", Sys.getenv("SPACNA_CNV_EXPR_DIR", unset = Sys.getenv("AXIS_CNV_EXPR_DIR", unset = "results/multiomics/cnv_exp")))
  list(
    out_dir = out_dir,
    cnv_csv = get("--cnv-csv", file.path(out_dir, "clone_cnv_for_expr_integration.csv")),
    hq_csv = get("--hq-csv", file.path(out_dir, "derived_high_quality_from_mapping.csv")),
    cis_csv = get("--cis-csv", file.path(out_dir, "gene_cis_cnv_expr_correlation.csv")),
    gmap_csv = get("--gmap-csv", file.path(out_dir, "gene_bin_map.csv")),
    pb_d_csv = get("--pb-delta-csv", file.path(out_dir, "clone_pseudobulk_delta_vs_refclone.csv")),
    cnv_d_csv = get("--cnv-delta-csv", file.path(out_dir, "cnv_log2_delta_vs_refclone.csv")),
    expr_csv = get("--expr-csv", file.path(out_dir, "clone_pseudobulk_logmean_log2counts.csv")),
    ref_clone = get("--ref-clone", "1")
  )
}

msg <- function(...) message("[pub_cnv_expr] ", ...)

theme_pub <- function(base_size = 11) {
  theme_classic(base_size = base_size) +
    theme(
      plot.title = element_text(face = "bold", size = rel(1.1), hjust = 0),
      plot.subtitle = element_text(colour = "grey40", size = rel(0.88), hjust = 0),
      axis.title = element_text(colour = "grey20", size = rel(0.95)),
      panel.grid.major.y = element_line(colour = "grey92", linewidth = 0.3)
    )
}

main <- function() {
  cfg <- parse_args()
  out_dir <- cfg$out_dir
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

  need <- c(cfg$cnv_csv, cfg$cis_csv, cfg$gmap_csv, cfg$pb_d_csv, cfg$cnv_d_csv, cfg$expr_csv)
  miss <- need[!file.exists(need)]
  if (length(miss)) {
    stop(
      "Missing input files. Run run_cnv_expr_coupling() first.\n  ",
      paste(miss, collapse = "\n  ")
    )
  }

  cnv <- read.csv(cfg$cnv_csv, stringsAsFactors = FALSE)
  cis <- read.csv(cfg$cis_csv, stringsAsFactors = FALSE)
  gmap <- read.csv(cfg$gmap_csv, stringsAsFactors = FALSE)
  pb_d <- read.csv(cfg$pb_d_csv, row.names = 1, check.names = FALSE)
  cnv_d <- read.csv(cfg$cnv_d_csv, row.names = 1, check.names = FALSE)
  expr <- read.csv(cfg$expr_csv, row.names = 1, check.names = FALSE)
  hq <- if (file.exists(cfg$hq_csv)) read.csv(cfg$hq_csv, stringsAsFactors = FALSE) else NULL

  # Top coupling genes plot
  top <- head(cis[order(cis$FDR, -abs(cis$rho)), ], 30)
  top$gene_symbol <- factor(top$gene_symbol, levels = rev(top$gene_symbol))
  p_top <- ggplot(top, aes(x = rho, y = gene_symbol, fill = rho > 0)) +
    geom_col(width = 0.75, show.legend = FALSE) +
    scale_fill_manual(values = c(`TRUE` = "#C0392B", `FALSE` = "#2980B9")) +
    labs(
      title = "Top CNV–expression coupling genes",
      subtitle = "Spearman ρ (clone-level ΔCNV vs Δexpression)",
      x = "Spearman ρ", y = NULL
    ) +
    theme_pub()
  ggsave(file.path(out_dir, "Fig_coupling_top_genes.pdf"), p_top, width = 7, height = 8)

  # Top bins if present
  top_bins_path <- file.path(out_dir, "coupling_top_bins.csv")
  if (file.exists(top_bins_path)) {
    tb <- read.csv(top_bins_path, stringsAsFactors = FALSE)
    tb$matrix_col <- factor(tb$matrix_col, levels = rev(tb$matrix_col))
    p_bins <- ggplot(tb, aes(x = mean_abs_rho, y = matrix_col)) +
      geom_col(fill = "#2E6FB0", width = 0.75) +
      labs(
        title = "Top coupled 1 Mb bins",
        subtitle = "Mean |ρ| of genes mapped to each bin",
        x = "Mean |Spearman ρ|", y = "matrix_col"
      ) +
      theme_pub()
    ggsave(file.path(out_dir, "Fig_coupling_top_bins.pdf"), p_bins, width = 7, height = 6)
  }

  # Optional spatial HQ clones
  if (!is.null(hq) && all(c("x_coord", "y_coord", "dna_clone") %in% names(hq))) {
    hq$clone <- factor(hq$dna_clone)
    p_sp <- ggplot(hq, aes(x = x_coord, y = y_coord, colour = clone)) +
      geom_point(size = 1.2, alpha = 0.85) +
      coord_equal() +
      scale_y_reverse() +
      labs(title = "HQ spots by DNA clone", x = "Array X", y = "Array Y") +
      theme_pub() +
      theme(panel.grid = element_blank())
    ggsave(file.path(out_dir, "Fig_spatial_DNA_clones_HQ.pdf"), p_sp, width = 6, height = 6)
  }

  msg("Figures written under: ", out_dir)
  invisible(TRUE)
}

if (sys.nframe() == 0L || identical(sys.nframe(), 0)) {
  # When run via Rscript
}
main()
