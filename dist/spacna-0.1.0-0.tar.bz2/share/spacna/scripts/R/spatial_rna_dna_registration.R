# Legacy filename — use scripts/R/axis_dna_rna.R instead.
#
# source("scripts/R/spatial_rna_dna_registration.R")  # still works

.local <- tryCatch(
  dirname(normalizePath(sys.frame(1)$ofile, mustWork = FALSE)),
  error = function(e) file.path(Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = ".")), "scripts/R")
)
source(file.path(.local, "axis_dna_rna.R"))
