# Backward-compatible wrapper — prefer scripts/R/spatial_dna_analysis.R
#
# source("scripts/R/human_spatial_dna_analysis.R")
# still provides run_unified_spatial_dna() / export_for_medicc2() / ...

.local_dir <- tryCatch(
  dirname(normalizePath(sys.frame(1)$ofile, mustWork = FALSE)),
  error = function(e) file.path(Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = ".")), "scripts/R")
)
source(file.path(.local_dir, "spatial_dna_analysis.R"))
