# Legacy alias — prefer source("scripts/R/spacna_rna.R") or spacna.R
source(file.path(
  {
    candidates <- c(
      file.path(Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = "")), "scripts/R"),
      "scripts/R",
      "."
    )
    hit <- candidates[file.exists(file.path(candidates, "spacna_rna.R"))][1]
    if (is.na(hit)) stop("Cannot find spacna_rna.R; set SPACNA_REPO_ROOT")
    hit
  },
  "spacna_rna.R"
))
