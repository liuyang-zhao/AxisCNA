# AXIS-DNA-RNA: CNV–expression coupling (cis Spearman), top bins / genes, tables.
#
# Coupling score per gene = Spearman ρ between clone-level ΔCNV (bin) and
# Δexpression (gene), across DNA clones (ref_clone as baseline).
#
# Usage:
#   source("scripts/R/cnv_expr_coupling.R")
#   run_cnv_expr_coupling(
#     out_dir = "results/multiomics/cnv_exp",
#     high_quality_csv = "path/to/hq.csv",           # or mapping+rna_clustering
#     rna_matrix_tsv = "path/to/Decontaminated_filtered_matrix.tsv",
#     cnv_integration_csv = "path/to/clone_cnv_for_expr_integration.csv",
#     gene_bin_map_csv = "path/to/gene_bin_map.csv",
#     ref_clone = "1",
#     top_n_bins = 20L,
#     top_n_genes = 50L
#   )

suppressPackageStartupMessages({
  library(dplyr)
})

`%||%` <- function(a, b) if (!is.null(a) && length(a) > 0 && !(length(a) == 1 && is.na(a))) a else b

safe_dir <- function(d) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

read_tsv_matrix <- function(path, first_col_gene = TRUE, spots_x_genes = FALSE) {
  dt <- utils::read.delim(path, sep = "\t", header = TRUE, check.names = FALSE, stringsAsFactors = FALSE)
  if (isTRUE(spots_x_genes)) {
    spot_ids <- dt[[1L]]
    gcols <- seq_len(ncol(dt))[-1L]
    gene_names <- names(dt)[gcols]
    mat <- t(as.matrix(dt[, gcols, drop = FALSE]))
    colnames(mat) <- spot_ids
    rownames(mat) <- gene_names
  } else if (first_col_gene) {
    genes <- dt[[1L]]
    mat <- as.matrix(dt[, -1L, drop = FALSE])
    rownames(mat) <- genes
  } else {
    mat <- as.matrix(dt)
  }
  storage.mode(mat) <- "double"
  mat
}

pseudobulk_means <- function(count_mat, clone_vec) {
  u <- sort(unique(clone_vec))
  out <- matrix(NA_real_, nrow = length(u), ncol = nrow(count_mat),
                dimnames = list(as.character(u), rownames(count_mat)))
  for (cl in u) {
    idx <- which(clone_vec == cl)
    if (!length(idx)) next
    out[as.character(cl), ] <- rowMeans(log2(count_mat[, idx, drop = FALSE] + 1))
  }
  out
}

delta_vs_ref <- function(pb, ref = "1") {
  ref <- as.character(ref)
  if (!ref %in% rownames(pb)) return(pb)
  sweep(pb, 2L, pb[ref, , drop = TRUE], `-`)
}

cis_scan <- function(pb_expr, cnv_clones_by_bin, gene_map, method = "spearman") {
  rows <- list()
  for (i in seq_len(nrow(gene_map))) {
    g <- gene_map$gene_symbol[i]
    mc <- as.character(gene_map$matrix_col[i])
    if (!g %in% colnames(pb_expr)) next
    if (!mc %in% colnames(cnv_clones_by_bin)) next
    x <- as.numeric(pb_expr[, g])
    y <- as.numeric(cnv_clones_by_bin[, mc])
    if (length(x) < 2L || anyNA(x) || anyNA(y)) next
    ct <- tryCatch(stats::cor.test(x, y, method = method, exact = FALSE),
                   error = function(e) NULL)
    rho <- if (!is.null(ct)) unname(ct$estimate) else suppressWarnings(stats::cor(x, y, method = method))
    pval <- if (!is.null(ct)) ct$p.value else NA_real_
    rows[[length(rows) + 1L]] <- data.frame(
      gene_symbol = g, matrix_col = gene_map$matrix_col[i],
      rho = unname(rho), p_value = pval, stringsAsFactors = FALSE
    )
  }
  out <- do.call(rbind, rows)
  if (is.null(out) || !nrow(out)) return(data.frame())
  out$FDR <- p.adjust(out$p_value, method = "BH")
  out[order(out$FDR, -abs(out$rho)), , drop = FALSE]
}

build_hq_from_mapping_rna <- function(
    rna_to_dna_mapping_csv,
    rna_clustering_csv,
    mapping_qc_max_distance = 0.05
) {
  map <- utils::read.csv(rna_to_dna_mapping_csv, stringsAsFactors = FALSE)
  rna <- utils::read.csv(rna_clustering_csv, stringsAsFactors = FALSE)
  needm <- c("RNA_Barcode", "Mapped_DNA_Cluster", "Mapping_Distance")
  if (!all(needm %in% names(map))) {
    stop("mapping CSV needs columns: ", paste(needm, collapse = ", "))
  }
  if (!all(c("spot_id", "rna_cluster", "x_coord", "y_coord") %in% names(rna))) {
    stop("RNA table needs: spot_id, rna_cluster, x_coord, y_coord")
  }
  m <- merge(map, rna, by.x = "RNA_Barcode", by.y = "spot_id", all.x = FALSE)
  m <- m[!is.na(m$rna_cluster) & !is.na(m$Mapped_DNA_Cluster), , drop = FALSE]
  m <- m[!is.na(m$Mapping_Distance) & m$Mapping_Distance < mapping_qc_max_distance, , drop = FALSE]
  if (!nrow(m)) stop("No rows after merge / QC threshold")
  data.frame(
    spot_id = m$RNA_Barcode,
    x_coord = m$x_coord,
    y_coord = m$y_coord,
    dna_clone = as.numeric(as.character(m$Mapped_DNA_Cluster)),
    rna_cluster = as.numeric(as.character(m$rna_cluster)),
    mapping_distance = m$Mapping_Distance,
    stringsAsFactors = FALSE
  )
}

load_hq_table <- function(
    out_dir,
    high_quality_csv = NULL,
    rna_to_dna_mapping_csv = NULL,
    rna_clustering_csv = NULL,
    mapping_qc_max_distance = 0.05
) {
  if (!is.null(high_quality_csv) && nzchar(high_quality_csv) && file.exists(high_quality_csv)) {
    return(utils::read.csv(high_quality_csv, stringsAsFactors = FALSE))
  }
  if (!is.null(rna_to_dna_mapping_csv) && file.exists(rna_to_dna_mapping_csv) &&
      !is.null(rna_clustering_csv) && file.exists(rna_clustering_csv)) {
    hq <- build_hq_from_mapping_rna(
      rna_to_dna_mapping_csv, rna_clustering_csv, mapping_qc_max_distance
    )
    utils::write.csv(hq, file.path(out_dir, "derived_high_quality_from_mapping.csv"), row.names = FALSE)
    return(hq)
  }
  stop("Provide high_quality_csv OR (rna_to_dna_mapping_csv + rna_clustering_csv)")
}

#' Bin-level coupling: mean |ρ| of genes in each bin; rank top bins.
summarize_coupling_bins <- function(cis_df, gene_map, top_n = 20L) {
  if (is.null(cis_df) || !nrow(cis_df)) return(data.frame())
  gmap <- gene_map[, c("gene_symbol", "matrix_col")]
  if ("chr" %in% names(gene_map)) gmap$chr <- gene_map$chr
  if ("bin_start" %in% names(gene_map)) gmap$bin_start <- gene_map$bin_start
  if ("bin_end" %in% names(gene_map)) gmap$bin_end <- gene_map$bin_end
  m <- merge(cis_df, gmap, by = c("gene_symbol", "matrix_col"), all.x = TRUE)
  agg <- m %>%
    group_by(matrix_col) %>%
    summarise(
      n_genes = n(),
      mean_abs_rho = mean(abs(rho), na.rm = TRUE),
      max_abs_rho = max(abs(rho), na.rm = TRUE),
      mean_rho = mean(rho, na.rm = TRUE),
      min_FDR = min(FDR, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    arrange(desc(mean_abs_rho), desc(max_abs_rho))
  if ("chr" %in% names(m)) {
    meta <- m %>%
      group_by(matrix_col) %>%
      summarise(
        chr = dplyr::first(na.omit(chr)),
        bin_start = if ("bin_start" %in% names(m)) dplyr::first(na.omit(bin_start)) else NA,
        bin_end = if ("bin_end" %in% names(m)) dplyr::first(na.omit(bin_end)) else NA,
        .groups = "drop"
      )
    agg <- merge(agg, meta, by = "matrix_col", all.x = TRUE)
  }
  utils::head(agg, top_n)
}

genes_in_top_bins <- function(cis_df, top_bins_df) {
  if (is.null(cis_df) || !nrow(cis_df) || is.null(top_bins_df) || !nrow(top_bins_df)) {
    return(data.frame())
  }
  cis_df[cis_df$matrix_col %in% top_bins_df$matrix_col, , drop = FALSE]
}

#' End-to-end CNV–expression coupling analysis.
spacna_cnv_expr <- function(
    out_dir,
    rna_matrix_tsv,
    cnv_integration_csv,
    gene_bin_map_csv = NULL,
    high_quality_csv = NULL,
    rna_to_dna_mapping_csv = NULL,
    rna_clustering_csv = NULL,
    mapping_qc_max_distance = 0.05,
    ref_clone = "1",
    min_spots_per_clone = 5L,
    first_col_gene = TRUE,
    spots_x_genes = TRUE,
    top_n_bins = 20L,
    top_n_genes = 50L
) {
  safe_dir(out_dir)
  hq <- load_hq_table(
    out_dir, high_quality_csv, rna_to_dna_mapping_csv, rna_clustering_csv,
    mapping_qc_max_distance
  )
  stopifnot(all(c("spot_id", "dna_clone") %in% names(hq)))
  if (!file.exists(rna_matrix_tsv)) stop("rna_matrix_tsv not found: ", rna_matrix_tsv)
  if (!file.exists(cnv_integration_csv)) stop("cnv_integration_csv not found: ", cnv_integration_csv)

  counts <- read_tsv_matrix(rna_matrix_tsv, first_col_gene, spots_x_genes)
  common <- intersect(hq$spot_id, colnames(counts))
  if (length(common) < 10L) stop("Too few overlapping spots: ", length(common))
  hq <- hq[hq$spot_id %in% common, , drop = FALSE]
  counts <- counts[, common, drop = FALSE]
  clone_vec <- as.character(hq$dna_clone[match(colnames(counts), hq$spot_id)])
  tab <- table(clone_vec)
  keep <- names(tab)[tab >= min_spots_per_clone]
  counts <- counts[, clone_vec %in% keep, drop = FALSE]
  clone_vec <- as.character(hq$dna_clone[match(colnames(counts), hq$spot_id)])

  pb <- pseudobulk_means(counts, clone_vec)
  pb_d <- delta_vs_ref(pb, ref = ref_clone)
  utils::write.csv(pb, file.path(out_dir, "clone_pseudobulk_logmean_log2counts.csv"))
  utils::write.csv(pb_d, file.path(out_dir, "clone_pseudobulk_delta_vs_refclone.csv"))

  cnv <- utils::read.csv(cnv_integration_csv, stringsAsFactors = FALSE, check.names = FALSE)
  clcols <- grep("^clone_", names(cnv), value = TRUE)
  if (!length(clcols)) stop("CNV file needs clone_1, clone_2, ... columns")
  if (!"matrix_col" %in% names(cnv)) stop("CNV file needs matrix_col")
  mat <- t(as.matrix(cnv[, clcols, drop = FALSE]))
  colnames(mat) <- as.character(cnv[["matrix_col"]])
  rownames(mat) <- sub("^clone_", "", clcols)
  mat <- mat[intersect(rownames(pb), rownames(mat)), , drop = FALSE]
  pb <- pb[rownames(mat), , drop = FALSE]
  pb_d <- pb_d[rownames(mat), , drop = FALSE]
  cnv_d <- delta_vs_ref(mat, ref = ref_clone)
  utils::write.csv(cnv_d, file.path(out_dir, "cnv_log2_delta_vs_refclone.csv"))

  cis <- data.frame()
  top_bins <- data.frame()
  top_genes <- data.frame()
  if (!is.null(gene_bin_map_csv) && nzchar(gene_bin_map_csv) && file.exists(gene_bin_map_csv)) {
    gmap <- utils::read.csv(gene_bin_map_csv, stringsAsFactors = FALSE)
    cis <- cis_scan(pb_d, cnv_d, gmap)
    if (nrow(cis) > 0L) {
      utils::write.csv(cis, file.path(out_dir, "gene_cis_cnv_expr_correlation.csv"), row.names = FALSE)
      # coupling scores alias
      utils::write.csv(cis, file.path(out_dir, "coupling_scores_by_gene.csv"), row.names = FALSE)
      top_genes <- utils::head(cis, top_n_genes)
      utils::write.csv(top_genes, file.path(out_dir, "coupling_top_genes.csv"), row.names = FALSE)
      top_bins <- summarize_coupling_bins(cis, gmap, top_n = top_n_bins)
      utils::write.csv(top_bins, file.path(out_dir, "coupling_top_bins.csv"), row.names = FALSE)
      bin_genes <- genes_in_top_bins(cis, top_bins)
      utils::write.csv(bin_genes, file.path(out_dir, "coupling_top_bins_genes.csv"), row.names = FALSE)
    }
  } else {
    message("No gene_bin_map_csv — skipping gene-level coupling / top bins")
  }

  writeLines(
    c(
      sprintf("Spots: %d", ncol(counts)),
      sprintf("Clones: %s", paste(rownames(pb), collapse = ",")),
      sprintf("Coupling genes: %d", nrow(cis)),
      sprintf("Top bins written: %d", nrow(top_bins))
    ),
    file.path(out_dir, "RUN_SUMMARY.txt")
  )

  invisible(list(
    hq = hq, pb = pb, pb_delta = pb_d, cnv_delta = cnv_d,
    coupling = cis, top_bins = top_bins, top_genes = top_genes,
    out_dir = out_dir
  ))
}

# SpaCNA name alias
run_cnv_expr_coupling <- spacna_cnv_expr
