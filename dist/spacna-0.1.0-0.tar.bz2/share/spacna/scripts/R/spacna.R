# SpaCNA — main R entry point.
#
# Load once, then call functions by analysis role:
#
#   repo <- system("spacna path", intern = TRUE)
#   setwd(repo); Sys.setenv(SPACNA_REPO_ROOT = repo)
#   source("scripts/R/spacna.R")
#
# DNA CNV:
#   spacna_dna_cnv(expt_id, base_dir, species = "human", bin_size = "1Mb", ...)
#   spacna_compare_clones(expt_id_a, expt_id_b, base_dir)
#   spacna_export_medicc2(res_list, out_dir)
#   spacna_load_dna(expt_id, base_dir)
#
# SPI lineage:
#   spacna_spi(...)
#
# Phylogeny:
#   spacna_medicc2(...)
#
# RNA / multi-omics:
#   spacna_rna(...)
#   spacna_cnv_expr(...)
#   spacna_pseudotime(...)
#
# Reference (any bin size; package ships 1 Mb only):
#   spacna_gen_reference(species = "human", bin_size = "500kb", mode = "bins")

.spacna_r_dir <- local({
  candidates <- c(
    file.path(Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = "")), "scripts/R"),
    "scripts/R",
    file.path("..", "R")
  )
  hit <- candidates[file.exists(file.path(candidates, "species_defaults.R"))][1]
  if (is.na(hit)) stop("Cannot find scripts/R; set SPACNA_REPO_ROOT")
  normalizePath(hit, winslash = "/", mustWork = FALSE)
})

source(file.path(.spacna_r_dir, "species_defaults.R"))
source(file.path(.spacna_r_dir, "spatial_dna_analysis.R"))
source(file.path(.spacna_r_dir, "spi_lineage_analysis.R"))
source(file.path(.spacna_r_dir, "medicc2_evolution.R"))
source(file.path(.spacna_r_dir, "generate_reference.R"))
source(file.path(.spacna_r_dir, "spacna_rna.R"))

message("SpaCNA loaded. Main APIs: spacna_dna_cnv / spacna_spi / spacna_rna / spacna_gen_reference / spacna_medicc2")
