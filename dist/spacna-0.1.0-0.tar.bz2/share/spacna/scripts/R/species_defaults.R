# Species → default reference paths and chromosome order.
# Other species: use the human workflow; pass custom bins/gc/map paths.

#' Resolve SpaCNA install / repo root (SPACNA_REPO_ROOT, legacy AXIS_REPO_ROOT).
spacna_repo_root <- function(base_dir = NULL) {
  if (!is.null(base_dir) && nzchar(base_dir)) {
    return(normalizePath(base_dir, winslash = "/", mustWork = FALSE))
  }
  for (nm in c("SPACNA_REPO_ROOT", "AXIS_REPO_ROOT")) {
    env <- Sys.getenv(nm, unset = "")
    if (nzchar(env)) {
      return(normalizePath(env, winslash = "/", mustWork = FALSE))
    }
  }
  normalizePath(".", winslash = "/", mustWork = FALSE)
}

# Legacy alias
resolve_axis_repo_root <- spacna_repo_root

#' Format bin size as used in reference filenames (1Mb, 500kb, 2.5Mb, ...).
format_bin_label <- function(bin_size) {
  if (is.character(bin_size)) {
    s <- tolower(gsub("[_ ]", "", bin_size))
    if (grepl("mb$", s)) {
      bin_size <- as.numeric(sub("mb$", "", s)) * 1e6
    } else if (grepl("kb$", s)) {
      bin_size <- as.numeric(sub("kb$", "", s)) * 1e3
    } else if (grepl("bp$", s)) {
      bin_size <- as.numeric(sub("bp$", "", s))
    } else {
      bin_size <- as.numeric(s)
    }
  }
  bin_size <- as.numeric(bin_size)
  if (bin_size %% 1e6 == 0) {
    return(paste0(as.integer(bin_size / 1e6), "Mb"))
  }
  if (bin_size >= 1e6 && bin_size %% 1e5 == 0) {
    return(paste0(format(bin_size / 1e6, trim = TRUE, scientific = FALSE), "Mb"))
  }
  if (bin_size %% 1e3 == 0) {
    return(paste0(as.integer(bin_size / 1e3), "kb"))
  }
  paste0(as.integer(bin_size), "bp")
}

#' Default genomic resources for a species and bin size.
#'
#' Only 1 Mb bins / GC / mappability ship with the package. For any other size,
#' generate first (CLI or R):
#'   spacna gen-reference --species human --bin-size 500kb --mode all ...
#'   spacna_gen_reference(species = "human", bin_size = "500kb", mode = "all", ...)
resolve_species_resources <- function(
    species = "human",
    base_dir = NULL,
    bin_size = "1Mb"
) {
  base_dir <- spacna_repo_root(base_dir)
  species <- tolower(as.character(species)[1])
  label <- format_bin_label(bin_size)

  if (identical(species, "mouse")) {
    genome <- "GRCm39"
    map_name <- paste0("GRCm39_", label, "_map.txt")
    chr_levels <- c(as.character(1:19), "X", "Y")
  } else {
    genome <- if (identical(species, "human")) "GRCh38" else paste0(species, "_custom")
    map_name <- if (identical(species, "human") && identical(label, "1Mb")) {
      "hg38_1Mb_map.txt"
    } else {
      paste0(if (identical(species, "human")) "hg38" else genome, "_", label, "_map.txt")
    }
    chr_levels <- c(as.character(1:22), "X", "Y")
  }

  list(
    species = species,
    genome_label = genome,
    bin_label = label,
    bins_path = file.path(base_dir, "reference/genomic_bins", paste0(genome, "_", label, "_bins.txt")),
    gc_path = file.path(base_dir, "reference/gc_content", paste0(genome, "_", label, "_gc.txt")),
    map_path = file.path(base_dir, "reference/mappability", map_name),
    chr_levels = chr_levels
  )
}

#' Fill missing reference paths from species + bin_size defaults.
fill_species_paths <- function(
    species = "human",
    base_dir = NULL,
    bins_path = NULL,
    gc_path = NULL,
    map_path = NULL,
    bin_size = "1Mb"
) {
  res <- resolve_species_resources(species, base_dir, bin_size = bin_size)
  if (is.null(bins_path) || !nzchar(bins_path)) bins_path <- res$bins_path
  if (is.null(gc_path) || !nzchar(gc_path)) gc_path <- res$gc_path
  if (is.null(map_path) || !nzchar(map_path)) map_path <- res$map_path
  list(
    species = res$species,
    genome_label = res$genome_label,
    bin_label = res$bin_label,
    chr_levels = res$chr_levels,
    bins_path = bins_path,
    gc_path = gc_path,
    map_path = map_path
  )
}
