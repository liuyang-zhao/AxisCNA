# AXIS-DNA-RNA: Monocle2 pseudotime on a Seurat object.
#
# Requires: monocle (Bioconductor monocle / monocle2), Seurat, ggplot2, patchwork, viridis

spacna_pseudotime <- function(
    seurat_obj,
    output_dir,
    sample_id,
    cluster_col = "seurat_clusters",
    root_cluster = NULL
) {
  if (!requireNamespace("monocle", quietly = TRUE) && !requireNamespace("monocle2", quietly = TRUE)) {
    stop("Install monocle / monocle2 for pseudotime analysis.")
  }
  if (!requireNamespace("Seurat", quietly = TRUE)) stop("Seurat is required.")
  suppressPackageStartupMessages({
    library(ggplot2)
    library(patchwork)
    library(viridis)
    if (requireNamespace("monocle", quietly = TRUE)) library(monocle) else library(monocle2)
  })

  cat(sprintf("\n=== RNA pseudotime: %s ===\n", sample_id))
  expr_matrix <- as(as.matrix(seurat_obj@assays$RNA@counts), "sparseMatrix")
  cell_ann <- seurat_obj@meta.data
  gene_ann <- data.frame(gene_short_name = rownames(expr_matrix), row.names = rownames(expr_matrix))

  pd <- new("AnnotatedDataFrame", data = cell_ann)
  fd <- new("AnnotatedDataFrame", data = gene_ann)
  cds <- newCellDataSet(
    expr_matrix, phenoData = pd, featureData = fd,
    lowerDetectionLimit = 0.5, expressionFamily = negbinomial.size()
  )
  cds <- estimateSizeFactors(cds)
  cds <- estimateDispersions(cds)

  var_genes <- if ("SCT" %in% names(seurat_obj@assays)) {
    Seurat::VariableFeatures(seurat_obj, assay = "SCT")
  } else {
    Seurat::VariableFeatures(seurat_obj)
  }
  if (length(var_genes) == 0) stop("No VariableFeatures in Seurat object.")
  cds <- setOrderingFilter(cds, var_genes)
  cds <- reduceDimension(cds, max_components = 2, method = "DDRTree")
  cds <- orderCells(cds)

  if (!is.null(root_cluster) && root_cluster %in% pData(cds)[[cluster_col]]) {
    state_table <- table(pData(cds)$State[pData(cds)[[cluster_col]] == root_cluster])
    root_state <- names(which.max(state_table))
    cds <- orderCells(cds, root_state = root_state)
  }

  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  p1 <- plot_cell_trajectory(cds, color_by = cluster_col, cell_size = 1.2)
  p2 <- plot_cell_trajectory(cds, color_by = "Pseudotime", cell_size = 1.2) +
    scale_color_viridis_c(option = "mako")
  ggplot2::ggsave(
    file.path(output_dir, paste0(sample_id, "_RNA_Pseudotime.pdf")),
    p1 | p2, width = 12, height = 5
  )
  invisible(cds)
}

# SpaCNA name alias
run_rna_pseudotime_monocle2 <- spacna_pseudotime
