# AXIS-DNA-RNA: SpotClean → Seurat → inferCNV (function API; no hardcoded paths).
#
# Requires Bioconductor/CRAN: SpotClean, Seurat, infercnv (optional until called).
#
# Example:
#   source("scripts/R/spatial_rna_analysis.R")
#   run_spatial_rna_pipeline(
#     sample_id = "1_3",
#     raw_matrix_dir = file.path(Sys.getenv("SPACNA_RNA_DIR", unset = Sys.getenv("AXIS_RNA_DIR", unset = "")), "1_3/raw_feature_bc_matrix"),
#     slide_info_path = file.path(Sys.getenv("SPACNA_RNA_DIR", unset = Sys.getenv("AXIS_RNA_DIR", unset = "")), "1_3/slide_info.txt"),
#     out_dir = file.path("results/Spatial_RNA", "1_3"),
#     gene_order_file = Sys.getenv("SPACNA_INFERCNV_GENE_ORDER", unset = Sys.getenv("AXIS_INFERCNV_GENE_ORDER", unset = "")),  # optional
#     run_infercnv = TRUE
#   )

require_pkg <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop("Package '", pkg, "' is required. Install it before running this step.", call. = FALSE)
  }
}

#' Run SpotClean decontamination + Seurat clustering; optionally inferCNV.
spacna_rna <- function(
    sample_id,
    raw_matrix_dir,
    out_dir,
    slide_info_path = NULL,
    tissue_positions_path = NULL,
    run_spotclean = TRUE,
    run_seurat = TRUE,
    run_infercnv = FALSE,
    gene_order_file = NULL,
    reference_annotations = NULL,
    n_pcs = 30L,
    resolution = 0.5
) {
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(raw_matrix_dir)) stop("raw_matrix_dir not found: ", raw_matrix_dir)

  seurat_obj <- NULL
  decontam_path <- file.path(out_dir, "Decontaminated_filtered_matrix.tsv")

  if (isTRUE(run_spotclean)) {
    require_pkg("SpotClean")
    require_pkg("Seurat")
    message("[rna] SpotClean on ", raw_matrix_dir)
    # SpotClean expects 10x raw matrix + spatial metadata when available
    raw <- Seurat::Read10X(raw_matrix_dir)
    # Minimal path: create Seurat, write counts for downstream if SpotClean
    # metadata missing (user can replace with full SpotClean::spotclean call).
    if (!is.null(slide_info_path) && file.exists(slide_info_path) &&
        requireNamespace("SpotClean", quietly = TRUE)) {
      message("[rna] Prefer calling SpotClean::read10xRaw / spotclean with your slide metadata.")
    }
    seurat_obj <- Seurat::CreateSeuratObject(raw, min.cells = 10)
    mat <- as.matrix(Seurat::GetAssayData(seurat_obj, layer = "counts"))
    utils::write.table(
      cbind(gene = rownames(mat), as.data.frame(mat)),
      decontam_path, sep = "\t", quote = FALSE, row.names = FALSE
    )
    message("[rna] Wrote matrix: ", decontam_path)
  }

  if (isTRUE(run_seurat)) {
    require_pkg("Seurat")
    if (is.null(seurat_obj)) {
      if (file.exists(decontam_path)) {
        dt <- utils::read.delim(decontam_path, check.names = FALSE)
        mat <- as.matrix(dt[, -1, drop = FALSE])
        rownames(mat) <- dt[[1]]
        seurat_obj <- Seurat::CreateSeuratObject(mat, min.cells = 10)
      } else {
        seurat_obj <- Seurat::CreateSeuratObject(Seurat::Read10X(raw_matrix_dir), min.cells = 10)
      }
    }
    message("[rna] Seurat SCT / neighbors / clusters")
    seurat_obj <- Seurat::SCTransform(seurat_obj, verbose = FALSE)
    seurat_obj <- Seurat::RunPCA(seurat_obj, verbose = FALSE)
    seurat_obj <- Seurat::FindNeighbors(seurat_obj, dims = 1:n_pcs)
    seurat_obj <- Seurat::FindClusters(seurat_obj, resolution = resolution)
    seurat_obj <- Seurat::RunUMAP(seurat_obj, dims = 1:n_pcs)
    saveRDS(seurat_obj, file.path(out_dir, paste0(sample_id, "_seurat.rds")))
    meta <- seurat_obj@meta.data
    meta$spot_id <- rownames(meta)
    utils::write.csv(
      meta,
      file.path(out_dir, "rna_clustering_results_complete.csv"),
      row.names = FALSE
    )
  }

  if (isTRUE(run_infercnv)) {
    require_pkg("infercnv")
    if (is.null(seurat_obj)) stop("Seurat object required for inferCNV")
    if (is.null(gene_order_file) || !file.exists(gene_order_file)) {
      stop("Set gene_order_file to a valid inferCNV gene order file")
    }
    message("[rna] inferCNV")
    counts <- as.matrix(Seurat::GetAssayData(seurat_obj, layer = "counts"))
    annot <- data.frame(
      cell = colnames(counts),
      group = as.character(Seurat::Idents(seurat_obj)),
      stringsAsFactors = FALSE
    )
    annot_file <- file.path(out_dir, paste0(sample_id, "_infercnv_annotations.txt"))
    utils::write.table(annot, annot_file, sep = "\t", quote = FALSE, row.names = FALSE, col.names = FALSE)
    infercnv_obj <- infercnv::CreateInfercnvObject(
      raw_counts_matrix = counts,
      annotations_file = annot_file,
      delim = "\t",
      gene_order_file = gene_order_file,
      ref_group_names = reference_annotations
    )
    infercnv_dir <- file.path(out_dir, "infercnv_output")
    infercnv_obj <- infercnv::run(
      infercnv_obj,
      cutoff = 0.1,
      out_dir = infercnv_dir,
      cluster_by_groups = TRUE,
      denoise = TRUE,
      HMM = FALSE
    )
    saveRDS(infercnv_obj, file.path(out_dir, paste0(sample_id, "_infercnv.rds")))
  }

  invisible(list(seurat = seurat_obj, out_dir = out_dir, matrix_tsv = decontam_path))
}

# SpaCNA name alias
run_spatial_rna_pipeline <- spacna_rna
