# Backward-compatible mouse wrapper — prefer run_spatial_dna(species = "mouse", ...)
#
# source("scripts/R/mouse_spatial_dna_analysis.R")
# still provides run_slide_dna_mouse()

.local_dir <- tryCatch(
  dirname(normalizePath(sys.frame(1)$ofile, mustWork = FALSE)),
  error = function(e) file.path(Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = ".")), "scripts/R")
)
source(file.path(.local_dir, "spatial_dna_analysis.R"))
