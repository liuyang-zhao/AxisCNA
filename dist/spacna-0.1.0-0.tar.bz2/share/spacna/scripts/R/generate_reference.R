# Generate SpaCNA reference tables (bins / GC / mappability) for an arbitrary bin size.
# Only 1 Mb tables ship with the package; call this after downloading FASTA / bigWig.
#
# Usage:
#   source("scripts/R/spacna.R")
#   spacna_gen_reference(species = "human", bin_size = "500kb", mode = "bins")
#   spacna_gen_reference(
#     species = "human", bin_size = "500kb", mode = "all",
#     fasta = Sys.getenv("SPACNA_HUMAN_FASTA"),
#     mappability_bw = Sys.getenv("SPACNA_HUMAN_MAP_BW")
#   )

.spacna_r_dir <- local({
  candidates <- c(
    file.path(Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = "")), "scripts/R"),
    "scripts/R",
    file.path("..", "R"),
    dirname(normalizePath(".", winslash = "/", mustWork = FALSE))
  )
  hit <- candidates[file.exists(file.path(candidates, "species_defaults.R"))][1]
  if (is.na(hit)) stop("Cannot find species_defaults.R; set SPACNA_REPO_ROOT")
  normalizePath(hit, winslash = "/", mustWork = FALSE)
})
source(file.path(.spacna_r_dir, "species_defaults.R"))

#' Generate genomic bins and optional GC / mappability for any bin size.
#'
#' Wraps `scripts/reference/generate_reference.py` (same as `spacna gen-reference`).
#' Package ships 1 Mb only; use this for other resolutions.
spacna_gen_reference <- function(
    species = "human",
    bin_size = "500kb",
    mode = c("bins", "gc", "map", "all"),
    fasta = NULL,
    mappability_bw = NULL,
    chrom_sizes = NULL,
    genome_tag = NULL,
    out_dir = NULL,
    base_dir = NULL,
    repo_root = NULL
) {
  mode <- match.arg(mode)
  root <- spacna_repo_root(if (!is.null(repo_root)) repo_root else base_dir)
  py <- file.path(root, "scripts/reference/generate_reference.py")
  if (!file.exists(py)) {
    stop("generate_reference.py not found at: ", py)
  }

  args <- c(
    py,
    "--repo-root", root,
    "--species", as.character(species)[1],
    "--bin-size", as.character(bin_size)[1],
    "--mode", mode
  )
  if (!is.null(fasta) && nzchar(fasta)) {
    args <- c(args, "--fasta", fasta)
  }
  if (!is.null(mappability_bw) && nzchar(mappability_bw)) {
    args <- c(args, "--mappability-bw", mappability_bw)
  }
  if (!is.null(chrom_sizes) && nzchar(chrom_sizes)) {
    args <- c(args, "--chrom-sizes", chrom_sizes)
  }
  if (!is.null(genome_tag) && nzchar(genome_tag)) {
    args <- c(args, "--genome-tag", genome_tag)
  }
  if (!is.null(out_dir) && nzchar(out_dir)) {
    args <- c(args, "--out-dir", out_dir)
  }

  status <- system2("python", args = args)
  if (!identical(as.integer(status), 0L)) {
    stop("generate_reference.py failed with status ", status)
  }

  res <- resolve_species_resources(species, root, bin_size = bin_size)
  message("Reference ready for bin_size=", res$bin_label)
  message("  bins: ", res$bins_path)
  if (mode %in% c("gc", "all")) message("  gc:   ", res$gc_path)
  if (mode %in% c("map", "all")) message("  map:  ", res$map_path)
  invisible(res)
}

# Legacy alias
generate_axis_reference <- spacna_gen_reference
