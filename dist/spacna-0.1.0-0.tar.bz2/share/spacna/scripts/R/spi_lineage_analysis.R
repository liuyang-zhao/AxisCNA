# AXIS-DNA-seq: directional lineage & region-level CNA signature analysis.
#
#   1. Subclone Persistence Index (SPI) heatmap
#   2. Event-origin decomposition (truncal / inherited / private)
#   3. Clone fate classification (persistent / emergent / eradicated)
#   4. Surviving vs eradicated differential CNA at 1 Mb resolution
#
# Subclone Persistence Index (SPI)
# --------------------------------
# SPI(pre → post) = |E_pre ∩ E_post| / |E_pre|
#   fraction of a pre-chemo clone's segment-level CNA events retained in a
#   post-chemo clone. Asymmetric (directional); high SPI means the post clone
#   is a candidate descendant of the pre clone.
#
# Input options
# -------------
# 1) MEDICC2-style absolute CN table (sample_id, chrom, start, end, cn)
# 2) Named list of per-clone numeric CN / log2-ratio vectors + bin annotation
#
# Usage
# -----
#   source("scripts/R/spi_lineage_analysis.R")
#   res <- run_spi_lineage_analysis(
#     cn_table_path = "results/MEDICC2_Input/Chemo_Evolution_medicc2_input.tsv",
#     clone_groups = list(
#       pre  = c("17_1_C1", "19_1_C1", "20_1_C1"),
#       post = c("19_2_C1", "19_3_C1", "20_2_C1")
#     ),
#     out_dir = "results/SPI_lineage"
#   )

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(data.table)
})


# ===================== 1. Definitions & helpers =============================

#' Subclone Persistence Index (SPI)
#'
#' Directional containment of segment-level CNA event sets:
#'   SPI(pre → post) = |E_pre ∩ E_post| / |E_pre|
#'
#' @param events_pre  character / integer vector of event IDs in the pre clone
#' @param events_post character / integer vector of event IDs in the post clone
#' @return numeric scalar in [0, 1]; NA if |E_pre| == 0
spi <- function(events_pre, events_post) {
  e_pre <- unique(as.character(events_pre))
  e_post <- unique(as.character(events_post))
  if (length(e_pre) == 0L) {
    return(NA_real_)
  }
  length(intersect(e_pre, e_post)) / length(e_pre)
}


#' Convert absolute copy-number (or log2 ratio) profile to event IDs.
#'
#' Absolute CN mode (default): gain if cn >= diploid + gain_delta;
#'                             loss if cn <= diploid - loss_delta.
#' Log2-ratio mode: gain if log2 >= log2_gain_thr; loss if log2 <= log2_loss_thr.
#'
#' Event IDs are "gain:<bin_id>" or "loss:<bin_id>" so gain and loss at the
#' same bin are distinct events.
events_from_cn_profile <- function(
    cn_vec,
    bin_ids,
    mode = c("absolute", "log2"),
    diploid = 2,
    gain_delta = 1,
    loss_delta = 1,
    log2_gain_thr = 0.3,
    log2_loss_thr = -0.3
) {
  mode <- match.arg(mode)
  stopifnot(length(cn_vec) == length(bin_ids))
  cn_vec <- as.numeric(cn_vec)
  ok <- is.finite(cn_vec)

  if (mode == "absolute") {
    is_gain <- ok & cn_vec >= (diploid + gain_delta)
    is_loss <- ok & cn_vec <= (diploid - loss_delta)
  } else {
    is_gain <- ok & cn_vec >= log2_gain_thr
    is_loss <- ok & cn_vec <= log2_loss_thr
  }

  c(
    paste0("gain:", bin_ids[is_gain]),
    paste0("loss:", bin_ids[is_loss])
  )
}


#' Build per-clone event sets from a MEDICC2-style long table.
#'
#' @param cn_df data.frame with columns sample_id, chrom, start, end, cn
#' @param exclude_samples sample IDs to drop (e.g. Diploid_Root)
#' @return list(events = named list of character vectors,
#'              profiles = clone x bin matrix of CN,
#'              bins = bin annotation data.frame)
build_event_sets_from_medicc2_table <- function(
    cn_df,
    exclude_samples = c("Diploid_Root"),
    mode = "absolute",
    diploid = 2,
    gain_delta = 1,
    loss_delta = 1,
    log2_gain_thr = 0.3,
    log2_loss_thr = -0.3
) {
  required <- c("sample_id", "chrom", "start", "end", "cn")
  missing <- setdiff(required, names(cn_df))
  if (length(missing) > 0L) {
    stop("cn_df missing columns: ", paste(missing, collapse = ", "))
  }

  cn_df <- as.data.frame(cn_df, stringsAsFactors = FALSE)
  cn_df$chrom <- gsub("^chr", "", as.character(cn_df$chrom))
  cn_df$bin_id <- paste(cn_df$chrom, cn_df$start, cn_df$end, sep = ":")

  clones <- setdiff(unique(as.character(cn_df$sample_id)), exclude_samples)
  if (length(clones) < 2L) {
    stop("Need >= 2 clones after excluding: ", paste(exclude_samples, collapse = ", "))
  }

  # shared bin order (autosomes preferred)
  bins <- unique(cn_df[, c("bin_id", "chrom", "start", "end")])
  bins$chrom_num <- suppressWarnings(as.integer(bins$chrom))
  bins <- bins[order(bins$chrom_num, bins$start, bins$end, na.last = TRUE), , drop = FALSE]
  bin_ids <- bins$bin_id

  mat <- matrix(NA_real_, nrow = length(clones), ncol = length(bin_ids),
                dimnames = list(clones, bin_ids))
  for (cl in clones) {
    sub <- cn_df[cn_df$sample_id == cl, , drop = FALSE]
    mat[cl, sub$bin_id] <- as.numeric(sub$cn)
  }

  events <- lapply(clones, function(cl) {
    events_from_cn_profile(
      cn_vec = mat[cl, ],
      bin_ids = bin_ids,
      mode = mode,
      diploid = diploid,
      gain_delta = gain_delta,
      loss_delta = loss_delta,
      log2_gain_thr = log2_gain_thr,
      log2_loss_thr = log2_loss_thr
    )
  })
  names(events) <- clones

  list(events = events, profiles = mat, bins = bins)
}


# ===================== 2. SPI matrix ============================

#' Compute SPI matrix: rows = pre clones, columns = post clones.
#'
#' @param events named list of event-ID vectors
#' @param pre_clones character vector of pre-chemo clone IDs
#' @param post_clones character vector of post-chemo clone IDs
#' @return numeric matrix with dimnames
compute_spi_matrix <- function(events, pre_clones, post_clones) {
  pre_clones <- as.character(pre_clones)
  post_clones <- as.character(post_clones)
  miss <- setdiff(c(pre_clones, post_clones), names(events))
  if (length(miss) > 0L) {
    stop("Unknown clone IDs in event sets: ", paste(miss, collapse = ", "))
  }

  mat <- matrix(NA_real_, nrow = length(pre_clones), ncol = length(post_clones),
                dimnames = list(pre_clones, post_clones))
  for (pre in pre_clones) {
    for (post in post_clones) {
      mat[pre, post] <- spi(events[[pre]], events[[post]])
    }
  }
  mat
}


#' Best candidate ancestor for each post-chemo clone (max SPI across pre).
summarize_spi_ancestors <- function(spi_mat, min_spi = 0.6) {
  if (is.null(dim(spi_mat)) || ncol(spi_mat) == 0L) {
    return(data.frame())
  }
  rows <- lapply(colnames(spi_mat), function(post) {
    vals <- spi_mat[, post]
    best_pre <- names(vals)[which.max(vals)]
    best_spi <- as.numeric(vals[best_pre])
    data.frame(
      post_clone = post,
      best_pre_ancestor = best_pre,
      spi = best_spi,
      ancestor_identifiable = is.finite(best_spi) & best_spi >= min_spi,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}


plot_spi_heatmap <- function(spi_mat, out_file, title = "Subclone Persistence Index (SPI)") {
  df <- as.data.frame(as.table(spi_mat), stringsAsFactors = FALSE)
  names(df) <- c("pre", "post", "SPI")
  df$pre <- factor(df$pre, levels = rev(rownames(spi_mat)))
  df$post <- factor(df$post, levels = colnames(spi_mat))

  p <- ggplot(df, aes(x = post, y = pre, fill = SPI)) +
    geom_tile(color = "white", linewidth = 0.3) +
    geom_text(aes(label = ifelse(is.na(SPI), "", sprintf("%.2f", SPI))),
              size = 2.6, color = "grey15") +
    scale_fill_gradient(
      low = "#F7FBFF", high = "#08519C",
      limits = c(0, 1), na.value = "grey90",
      name = "SPI\n(pre→post)"
    ) +
    labs(
      title = title,
      subtitle = "SPI(pre→post) = |E_pre ∩ E_post| / |E_pre|; read down each column for candidate ancestors",
      x = "Post-chemo clone",
      y = "Pre-chemo clone"
    ) +
    theme_minimal(base_size = 11) +
    theme(
      axis.text.x = element_text(angle = 55, hjust = 1, size = 8),
      axis.text.y = element_text(size = 8),
      panel.grid = element_blank(),
      plot.subtitle = element_text(size = 8.5, color = "grey40")
    )

  ggsave(out_file, p, width = max(7, 0.45 * ncol(spi_mat) + 3),
         height = max(5, 0.35 * nrow(spi_mat) + 2.5), limitsize = FALSE)
  invisible(p)
}


# ===================== 3. 2. event-origin decomposition ===========

#' Partition each post-chemo clone's events into truncal / inherited / private.
#'
#' Truncal   = present in ALL clones (pre ∪ post)
#' Inherited = in post AND in ≥1 pre clone, excluding truncal
#' Private   = in post AND absent from every pre clone
decompose_event_origin <- function(events, pre_clones, post_clones) {
  pre_clones <- as.character(pre_clones)
  post_clones <- as.character(post_clones)
  all_clones <- unique(c(pre_clones, post_clones))

  truncal <- Reduce(intersect, events[all_clones])
  if (is.null(truncal)) truncal <- character(0)
  pre_union <- unique(unlist(events[pre_clones], use.names = FALSE))

  rows <- lapply(post_clones, function(post) {
    e_post <- unique(events[[post]])
    e_trunc <- intersect(e_post, truncal)
    e_inh <- setdiff(intersect(e_post, pre_union), truncal)
    e_priv <- setdiff(e_post, pre_union)
    n <- length(e_post)
    data.frame(
      post_clone = post,
      n_events = n,
      n_truncal = length(e_trunc),
      n_inherited = length(e_inh),
      n_private = length(e_priv),
      frac_truncal = if (n > 0) length(e_trunc) / n else NA_real_,
      frac_inherited = if (n > 0) length(e_inh) / n else NA_real_,
      frac_private = if (n > 0) length(e_priv) / n else NA_real_,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}


plot_event_origin_bars <- function(decomp_df, out_file) {
  long <- decomp_df %>%
    select(post_clone, frac_truncal, frac_inherited, frac_private) %>%
    pivot_longer(
      cols = starts_with("frac_"),
      names_to = "origin",
      values_to = "fraction"
    ) %>%
    mutate(
      origin = factor(
        origin,
        levels = c("frac_truncal", "frac_inherited", "frac_private"),
        labels = c("Truncal", "Inherited", "Private / acquired")
      ),
      post_clone = factor(post_clone, levels = rev(unique(decomp_df$post_clone)))
    )

  p <- ggplot(long, aes(x = fraction, y = post_clone, fill = origin)) +
    geom_col(width = 0.75, color = NA) +
    scale_fill_manual(
      values = c(
        "Truncal" = "#9aa3ad",
        "Inherited" = "#2E6FB0",
        "Private / acquired" = "#E58F2C"
      ),
      name = "Event origin"
    ) +
    scale_x_continuous(labels = function(x) paste0(round(100 * x), "%"), expand = c(0, 0)) +
    labs(
      title = "Event-origin decomposition of post-chemo clones",
      subtitle = "Large private fraction → candidate emergent; small private → persistent / descendant",
      x = "Fraction of clone events",
      y = NULL
    ) +
    theme_minimal(base_size = 11) +
    theme(panel.grid.major.y = element_blank(), plot.subtitle = element_text(size = 8.5, color = "grey40"))

  ggsave(out_file, p, width = 8, height = max(4, 0.35 * nrow(decomp_df) + 2), limitsize = FALSE)
  invisible(p)
}


# ===================== 4. 3. clone fate classification ===========

#' Classify post clones as persistent / emergent and pre clones as
#' eradicated / ancestral based on SPI and private-event fraction.
#'
#' @param spi_mat SPI matrix (pre x post)
#' @param decomp_df output of decompose_event_origin()
#' @param min_spi threshold for "ancestor identifiable" (default 0.6)
#' @param private_emergent_thr private fraction above which a post clone is
#'   labelled emergent (default 0.35)
classify_clone_fate <- function(
    spi_mat,
    decomp_df,
    min_spi = 0.6,
    private_emergent_thr = 0.35
) {
  anc <- summarize_spi_ancestors(spi_mat, min_spi = min_spi)
  anc <- merge(anc, decomp_df[, c("post_clone", "frac_private", "frac_inherited")],
               by = "post_clone", all.x = TRUE)

  anc$post_fate <- ifelse(
    is.na(anc$ancestor_identifiable) | !anc$ancestor_identifiable |
      is.na(anc$frac_private) | anc$frac_private >= private_emergent_thr,
    "emergent",
    "persistent"
  )

  # Pre clones that never serve as identifiable ancestors of any persistent post
  # clone are candidate-sensitive / eradicated.
  pre_ids <- rownames(spi_mat)
  persistent_posts <- anc$post_clone[anc$post_fate == "persistent"]
  ancestral_pres <- character(0)
  if (length(persistent_posts) > 0L) {
    sub <- spi_mat[, persistent_posts, drop = FALSE]
    ancestral_pres <- unique(unlist(lapply(seq_len(ncol(sub)), function(j) {
      vals <- sub[, j]
      names(vals)[is.finite(vals) & vals >= min_spi]
    })))
  }

  pre_fate <- data.frame(
    pre_clone = pre_ids,
    pre_fate = ifelse(pre_ids %in% ancestral_pres, "ancestral_of_persistent", "eradicated_candidate"),
    stringsAsFactors = FALSE
  )

  list(post_fate = anc, pre_fate = pre_fate)
}


# ===================== 5. Differential CNA (1 Mb) ===========================

#' Mean CN difference: surviving (persistent + emergent post) − eradicated pre.
#'
#' @param profiles clone x bin CN matrix
#' @param surviving_clones character vector
#' @param eradicated_clones character vector
#' @param bins bin annotation with bin_id, chrom, start, end
#' @return data.frame ranked by |ΔCN|
compute_differential_cna <- function(
    profiles,
    surviving_clones,
    eradicated_clones,
    bins
) {
  surviving_clones <- intersect(surviving_clones, rownames(profiles))
  eradicated_clones <- intersect(eradicated_clones, rownames(profiles))
  if (length(surviving_clones) < 1L || length(eradicated_clones) < 1L) {
    stop("Need ≥1 surviving and ≥1 eradicated clone for differential CNA.")
  }

  surv_mean <- colMeans(profiles[surviving_clones, , drop = FALSE], na.rm = TRUE)
  erad_mean <- colMeans(profiles[eradicated_clones, , drop = FALSE], na.rm = TRUE)
  delta <- surv_mean - erad_mean

  # Within-patient descriptive Welch t-test per bin (n=1 patient; q is descriptive)
  pvals <- vapply(colnames(profiles), function(b) {
    x <- as.numeric(profiles[surviving_clones, b])
    y <- as.numeric(profiles[eradicated_clones, b])
    x <- x[is.finite(x)]
    y <- y[is.finite(y)]
    if (length(x) < 2L || length(y) < 2L || sd(c(x, y)) == 0) {
      return(NA_real_)
    }
    tryCatch(t.test(x, y)$p.value, error = function(e) NA_real_)
  }, numeric(1))

  qvals <- if (requireNamespace("stats", quietly = TRUE)) {
    p.adjust(pvals, method = "BH")
  } else {
    pvals
  }

  out <- data.frame(
    bin_id = colnames(profiles),
    chrom = bins$chrom[match(colnames(profiles), bins$bin_id)],
    start = bins$start[match(colnames(profiles), bins$bin_id)],
    end = bins$end[match(colnames(profiles), bins$bin_id)],
    mean_surviving = as.numeric(surv_mean),
    mean_eradicated = as.numeric(erad_mean),
    delta_cn = as.numeric(delta),
    p_within = as.numeric(pvals),
    q_within = as.numeric(qvals),
    stringsAsFactors = FALSE
  )
  out$direction <- ifelse(out$delta_cn > 0, "gain", "loss")
  out <- out[order(-abs(out$delta_cn)), , drop = FALSE]
  rownames(out) <- NULL
  out
}


#' Merge adjacent same-direction significant bins into differential regions.
merge_differential_regions <- function(
    diff_df,
    abs_delta_thr = 0.5,
    q_thr = 0.05,
    max_gap_bins = 1L
) {
  cand <- diff_df[
    is.finite(diff_df$delta_cn) &
      abs(diff_df$delta_cn) >= abs_delta_thr &
      (is.na(diff_df$q_within) | diff_df$q_within <= q_thr),
    ,
    drop = FALSE
  ]
  if (nrow(cand) == 0L) {
    return(data.frame())
  }

  cand <- cand[order(cand$chrom, cand$start), , drop = FALSE]
  regions <- list()
  cur <- cand[1, , drop = FALSE]
  n_bins <- 1L
  deltas <- cur$delta_cn

  flush_region <- function() {
    data.frame(
      chrom = cur$chrom[1],
      start = min(cur$start),
      end = max(cur$end),
      n_bins = n_bins,
      direction = cur$direction[1],
      mean_delta_cn = mean(deltas),
      min_q_within = if (all(is.na(cur$q_within))) NA_real_ else min(cur$q_within, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  }

  if (nrow(cand) == 1L) {
    return(flush_region())
  }

  for (i in 2:nrow(cand)) {
    same_chr <- identical(as.character(cand$chrom[i]), as.character(cur$chrom[1]))
    same_dir <- identical(cand$direction[i], cur$direction[1])
    # adjacency: next start within max_gap_bins * bin size of previous end
    bin_size <- max(1, median(cand$end - cand$start, na.rm = TRUE))
    adjacent <- same_chr && (cand$start[i] - max(cur$end)) <= (max_gap_bins + 1) * bin_size

    if (same_chr && same_dir && adjacent) {
      cur <- rbind(cur, cand[i, , drop = FALSE])
      n_bins <- n_bins + 1L
      deltas <- c(deltas, cand$delta_cn[i])
    } else {
      regions[[length(regions) + 1L]] <- flush_region()
      cur <- cand[i, , drop = FALSE]
      n_bins <- 1L
      deltas <- cur$delta_cn
    }
  }
  regions[[length(regions) + 1L]] <- flush_region()
  out <- do.call(rbind, regions)
  out$region_id <- paste0(out$chrom, ":", out$start, "-", out$end)
  out$span_mb <- (out$end - out$start) / 1e6
  out <- out[order(-abs(out$mean_delta_cn)), , drop = FALSE]
  rownames(out) <- NULL
  out
}


plot_differential_landscape <- function(diff_df, out_file, title = "Differential CNA (surviving − eradicated)") {
  df <- diff_df
  df$chrom_num <- suppressWarnings(as.integer(df$chrom))
  df <- df[is.finite(df$chrom_num) & df$chrom_num %in% 1:22, , drop = FALSE]
  df <- df[order(df$chrom_num, df$start), , drop = FALSE]

  chr_len <- tapply(df$end, df$chrom_num, max)
  chr_order <- as.integer(names(sort(as.integer(names(chr_len)))))
  cum <- c(0, cumsum(as.numeric(chr_len[as.character(chr_order)])))
  names(cum) <- c("0", as.character(chr_order))
  df$gpos <- cum[as.character(df$chrom_num)] + df$start

  # alternating chromosome backgrounds
  chr_df <- data.frame(
    chrom = chr_order,
    xmin = cum[as.character(chr_order)],
    xmax = cum[as.character(chr_order)] + as.numeric(chr_len[as.character(chr_order)]),
    stringsAsFactors = FALSE
  )
  chr_df$fill <- ifelse(seq_len(nrow(chr_df)) %% 2 == 0, "a", "b")

  p <- ggplot() +
    geom_rect(
      data = chr_df,
      aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = fill),
      alpha = 0.35, show.legend = FALSE
    ) +
    scale_fill_manual(values = c(a = "#f4f6f8", b = "#ffffff")) +
    geom_hline(yintercept = 0, color = "#c7ccd3") +
    geom_line(data = df, aes(x = gpos, y = delta_cn), color = "#3a3f47", linewidth = 0.35, alpha = 0.7) +
    geom_area(
      data = df[df$delta_cn >= 0, , drop = FALSE],
      aes(x = gpos, y = delta_cn),
      fill = "#C0392B", alpha = 0.25
    ) +
    geom_area(
      data = df[df$delta_cn <= 0, , drop = FALSE],
      aes(x = gpos, y = delta_cn),
      fill = "#2E6FB0", alpha = 0.25
    ) +
    scale_x_continuous(
      breaks = (chr_df$xmin + chr_df$xmax) / 2,
      labels = chr_df$chrom,
      expand = c(0.01, 0)
    ) +
    labs(
      title = title,
      subtitle = "ΔCN = mean(surviving) − mean(eradicated); 1 Mb bins",
      x = "Chromosome",
      y = "ΔCN"
    ) +
    theme_minimal(base_size = 11) +
    theme(
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),
      axis.text.x = element_text(size = 7),
      plot.subtitle = element_text(size = 8.5, color = "grey40")
    )

  ggsave(out_file, p, width = 12, height = 3.8)
  invisible(p)
}


# ===================== 6. Containment lineage tree inputs ====================

#' Strip truncal events (present in every pre+post clone) from event sets.
clonal_only_events <- function(events, pre_clones, post_clones) {
  all_clones <- unique(c(as.character(pre_clones), as.character(post_clones)))
  truncal <- Reduce(intersect, events[all_clones])
  if (is.null(truncal)) truncal <- character(0)
  out <- lapply(events, function(e) setdiff(unique(e), truncal))
  list(events = out, truncal = truncal)
}


#' Write tables expected by scripts/lineage/plot_containment_lineage_tree.py
export_containment_lineage_tree_inputs <- function(
    events,
    spi_mat_clonal,
    pre_clones,
    post_clones,
    out_dir
) {
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  pre_clones <- as.character(pre_clones)
  post_clones <- as.character(post_clones)
  all_clones <- unique(c(pre_clones, post_clones))

  clonal <- clonal_only_events(events, pre_clones, post_clones)
  truncal <- clonal$truncal
  ev_clonal <- clonal$events

  # Directed event long table (all events, including truncal)
  ev_rows <- lapply(all_clones, function(cl) {
    eids <- unique(events[[cl]])
    if (length(eids) == 0L) {
      return(NULL)
    }
    data.frame(clone_id = cl, event_id = eids, stringsAsFactors = FALSE)
  })
  ev_df <- do.call(rbind, ev_rows)
  fwrite(ev_df, file.path(out_dir, "01_directed_events_by_clone.tsv"), sep = "\t")

  trunc_df <- data.frame(event_id = truncal, stringsAsFactors = FALSE)
  fwrite(trunc_df, file.path(out_dir, "01_truncal_directed_events.tsv"), sep = "\t")

  # Event counts: prefer clonal-only sizes for tree arm scaling consistency
  counts <- data.frame(
    clone_id = all_clones,
    n_events = vapply(all_clones, function(cl) length(unique(ev_clonal[[cl]])), integer(1)),
    n_events_with_truncal = vapply(all_clones, function(cl) length(unique(events[[cl]])), integer(1)),
    stringsAsFactors = FALSE
  )
  fwrite(counts, file.path(out_dir, "01_clone_event_counts.tsv"), sep = "\t")

  # Binary event-by-clone matrix (rows=events, cols=clones)
  all_eids <- sort(unique(unlist(events[all_clones], use.names = FALSE)))
  if (length(all_eids) > 0L) {
    mat <- matrix(0L, nrow = length(all_eids), ncol = length(all_clones),
                  dimnames = list(all_eids, all_clones))
    for (cl in all_clones) {
      mat[intersect(all_eids, events[[cl]]), cl] <- 1L
    }
    fwrite(as.data.frame(mat), file.path(out_dir, "01_event_by_clone_matrix.tsv"),
           sep = "\t", row.names = TRUE)
  }

  # Clonal-only containment / SPI matrix (rows=pre, cols=post)
  fwrite(as.data.frame(spi_mat_clonal),
         file.path(out_dir, "02_containment_clonal_only_pre_to_post.tsv"),
         sep = "\t", row.names = TRUE)
  fwrite(as.data.frame(spi_mat_clonal),
         file.path(out_dir, "SPI_matrix_clonal_only.tsv"),
         sep = "\t", row.names = TRUE)

  invisible(list(
    truncal = truncal,
    clonal_events = ev_clonal,
    clone_event_counts = counts
  ))
}


#' Call the Python containment lineage tree plotter.
#'
#' Produces among others:
#'   07_containment_lineage_tree_by_pair_events.png / .pdf
plot_containment_lineage_tree <- function(
    out_dir,
    project_dir = Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = getwd())),
    tau = 0.8,
    post_arm_modes = "containment,pair_events",
    divider_label = "treatment",
    python = Sys.getenv("SPACNA_PYTHON", unset = Sys.getenv("AXIS_PYTHON", unset = "python"))
) {
  candidates <- c(
    file.path(project_dir, "scripts/lineage/plot_containment_lineage_tree.py"),
    file.path(
      Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = "")),
      "scripts/lineage/plot_containment_lineage_tree.py"
    )
  )
  # When this R file lives under scripts/R/, sibling path is scripts/lineage/
  src_path <- tryCatch(
    normalizePath(sys.frame(1)$ofile, winslash = "/", mustWork = FALSE),
    error = function(e) NA_character_
  )
  if (is.character(src_path) && length(src_path) == 1L && nzchar(src_path) && !is.na(src_path)) {
    candidates <- c(
      candidates,
      normalizePath(
        file.path(dirname(dirname(src_path)), "lineage/plot_containment_lineage_tree.py"),
        winslash = "/",
        mustWork = FALSE
      )
    )
  }
  script <- candidates[file.exists(candidates)][1]
  if (is.na(script) || !nzchar(script)) {
    warning(
      "plot_containment_lineage_tree.py not found; skip lineage tree plot.\n",
      "  Expected under: ", candidates[1]
    )
    return(invisible(NULL))
  }

  out_dir_abs <- normalizePath(out_dir, winslash = "/", mustWork = TRUE)
  args <- c(
    script,
    "--project-dir", normalizePath(project_dir, winslash = "/", mustWork = FALSE),
    "--out-dir", out_dir_abs,
    "--tau", as.character(tau),
    "--post-arm-modes", post_arm_modes,
    "--divider-label", divider_label,
    "--cna-source", "directed"
  )
  status <- system2(python, args = args)
  if (!identical(as.integer(status), 0L)) {
    warning(
      "Lineage tree plotter exited with status ", status,
      ". Ensure pandas/matplotlib/numpy are available (", python, ")."
    )
  }
  invisible(status)
}


# ===================== 7. End-to-end runner =================================

#' Run SPI / lineage / differential-CNA analysis.
#'
#' @param cn_table_path path to MEDICC2 input TSV
#'   (columns: sample_id, chrom, start, end, cn)
#' @param clone_groups list(pre = ..., post = ...) clone ID vectors
#' @param out_dir output directory
#' @param min_spi SPI threshold for ancestor call (default 0.6)
#' @param private_emergent_thr private-fraction threshold for emergent (default 0.35)
#' @param abs_delta_thr |ΔCN| threshold for region calling (default 0.5)
#' @param q_thr within-patient BH q threshold (default 0.05)
#' @param plot_lineage_tree if TRUE, write containment tables and run the
#'   Python tree plotter (07_containment_lineage_tree_by_pair_events.png)
#' @param lineage_tau containment threshold used by the tree plotter (default 0.8)
#' @param divider_label vertical divider label on the tree (default "treatment")
#' @param ... forwarded to build_event_sets_from_medicc2_table()
spacna_spi <- function(
    cn_table_path,
    clone_groups,
    out_dir,
    min_spi = 0.6,
    private_emergent_thr = 0.35,
    abs_delta_thr = 0.5,
    q_thr = 0.05,
    plot_lineage_tree = TRUE,
    lineage_tau = 0.8,
    divider_label = "treatment",
    ...
) {
  if (!file.exists(cn_table_path)) {
    stop("CN table not found: ", cn_table_path)
  }
  if (is.null(clone_groups$pre) || is.null(clone_groups$post)) {
    stop("clone_groups must be a list with elements $pre and $post")
  }

  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  fig_dir <- file.path(out_dir, "figures")
  dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

  cn_df <- fread(cn_table_path, data.table = FALSE)
  built <- build_event_sets_from_medicc2_table(cn_df, ...)

  pre <- as.character(clone_groups$pre)
  post <- as.character(clone_groups$post)
  miss <- setdiff(c(pre, post), names(built$events))
  if (length(miss) > 0L) {
    stop("clone_groups IDs not in CN table: ", paste(miss, collapse = ", "),
         "\nAvailable: ", paste(names(built$events), collapse = ", "))
  }

  # SPI
  spi_mat <- compute_spi_matrix(built$events, pre, post)
  fwrite(as.data.frame(spi_mat), file.path(out_dir, "SPI_matrix.tsv"),
         sep = "\t", row.names = TRUE)
  plot_spi_heatmap(spi_mat, file.path(fig_dir, "SPI_heatmap.pdf"))

  # event-origin decomposition
  decomp <- decompose_event_origin(built$events, pre, post)
  fwrite(decomp, file.path(out_dir, "event_origin_decomposition.tsv"), sep = "\t")
  plot_event_origin_bars(decomp, file.path(fig_dir, "event_origin_decomposition.pdf"))

  # clone fate
  fate <- classify_clone_fate(
    spi_mat, decomp,
    min_spi = min_spi,
    private_emergent_thr = private_emergent_thr
  )
  fwrite(fate$post_fate, file.path(out_dir, "post_clone_fate.tsv"), sep = "\t")
  fwrite(fate$pre_fate, file.path(out_dir, "pre_clone_fate.tsv"), sep = "\t")

  surviving <- fate$post_fate$post_clone
  eradicated <- fate$pre_fate$pre_clone[fate$pre_fate$pre_fate == "eradicated_candidate"]
  if (length(eradicated) == 0L) {
    warning("No eradicated_candidate pre clones; using all pre clones as eradicated set for differential CNA.")
    eradicated <- pre
  }

  # differential CNA
  diff_bins <- compute_differential_cna(
    profiles = built$profiles,
    surviving_clones = surviving,
    eradicated_clones = eradicated,
    bins = built$bins
  )
  fwrite(diff_bins, file.path(out_dir, "differential_cna_1Mb_bins.tsv"), sep = "\t")
  plot_differential_landscape(diff_bins, file.path(fig_dir, "differential_cna_landscape.pdf"))

  regions <- merge_differential_regions(
    diff_bins,
    abs_delta_thr = abs_delta_thr,
    q_thr = q_thr
  )
  fwrite(regions, file.path(out_dir, "differential_regions_ranked.tsv"), sep = "\t")

  # event-set sizes for QC
  event_sizes <- data.frame(
    clone_id = names(built$events),
    n_events = vapply(built$events, length, integer(1)),
    group = ifelse(names(built$events) %in% pre, "pre",
                   ifelse(names(built$events) %in% post, "post", "other")),
    stringsAsFactors = FALSE
  )
  fwrite(event_sizes, file.path(out_dir, "clone_event_counts.tsv"), sep = "\t")

  # Containment lineage tree (clonal-only SPI / pair-event arms)
  spi_mat_clonal <- NULL
  if (isTRUE(plot_lineage_tree)) {
    clonal <- clonal_only_events(built$events, pre, post)
    spi_mat_clonal <- compute_spi_matrix(clonal$events, pre, post)
    export_containment_lineage_tree_inputs(
      events = built$events,
      spi_mat_clonal = spi_mat_clonal,
      pre_clones = pre,
      post_clones = post,
      out_dir = out_dir
    )
    plot_spi_heatmap(
      spi_mat_clonal,
      file.path(fig_dir, "SPI_heatmap_clonal_only.pdf"),
      title = "SPI (clonal-only; truncal events removed)"
    )
    plot_containment_lineage_tree(
      out_dir = out_dir,
      project_dir = Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = getwd())),
      tau = lineage_tau,
      post_arm_modes = "containment,pair_events",
      divider_label = divider_label
    )
  }

  cat("=== SPI lineage analysis complete ===\n")
  cat("  SPI matrix:              ", file.path(out_dir, "SPI_matrix.tsv"), "\n")
  cat("  Event-origin table:      ", file.path(out_dir, "event_origin_decomposition.tsv"), "\n")
  cat("  Post clone fate:         ", file.path(out_dir, "post_clone_fate.tsv"), "\n")
  cat("  Pre clone fate:          ", file.path(out_dir, "pre_clone_fate.tsv"), "\n")
  cat("  Differential 1 Mb bins:  ", file.path(out_dir, "differential_cna_1Mb_bins.tsv"), "\n")
  cat("  Ranked regions:          ", file.path(out_dir, "differential_regions_ranked.tsv"), "\n")
  cat("  Figures:                 ", fig_dir, "\n")
  if (isTRUE(plot_lineage_tree)) {
    cat("  Lineage tree (pair Δ):   ",
        file.path(out_dir, "07_containment_lineage_tree_by_pair_events.png"), "\n")
  }

  list(
    spi_matrix = spi_mat,
    spi_matrix_clonal = spi_mat_clonal,
    event_origin = decomp,
    post_fate = fate$post_fate,
    pre_fate = fate$pre_fate,
    differential_bins = diff_bins,
    differential_regions = regions,
    events = built$events,
    profiles = built$profiles,
    out_dir = out_dir
  )
}


# ==============================================================================
# Usage example (set RUN_EXAMPLES <- TRUE)
# ==============================================================================

RUN_EXAMPLES <- FALSE

if (isTRUE(RUN_EXAMPLES)) {
  repo_root <- Sys.getenv("SPACNA_REPO_ROOT", unset = Sys.getenv("AXIS_REPO_ROOT", unset = normalizePath("../..", winslash = "/")))
  setwd(repo_root)

  # After export_for_medicc2() / export_merged_for_medicc2():
  cn_path <- file.path(repo_root, "results/MEDICC2_Input/Chemo_Evolution_medicc2_input.tsv")

  res_spi <- run_spi_lineage_analysis(
    cn_table_path = cn_path,
    clone_groups = list(
      pre  = c("17_1_C1", "19_1_C1", "20_1_C1"),   # edit to your pre-chemo clone IDs
      post = c("19_2_C1", "19_3_C1", "20_2_C1")    # edit to your post-chemo clone IDs
    ),
    out_dir = file.path(repo_root, "results/SPI_lineage"),
    min_spi = 0.6,
    private_emergent_thr = 0.35,
    abs_delta_thr = 0.5,
    q_thr = 0.05
  )
}

# SpaCNA name alias
run_spi_lineage_analysis <- spacna_spi
