#!/usr/bin/env python3
"""Containment / SPI lineage tree (pre→post).

Left arms: clonal CNA counts from MRCA. Right arms: either L=1-C (containment)
or |E_pre △ E_post| (pair_events mode).

Typical inputs (written by run_spi_lineage_analysis() or chemo directional
pipeline):
  02_containment_clonal_only_pre_to_post.tsv
  01_clone_event_counts.tsv
  01_directed_events_by_clone.tsv
  01_truncal_directed_events.tsv

Example:
  python scripts/lineage/plot_containment_lineage_tree.py \\
    --project-dir . \\
    --out-dir results/SPI_lineage \\
    --post-arm-modes pair_events
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.path import Path as MplPath

# TrueType (42) in PDF so text stays editable in Adobe Illustrator/InDesign.
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["ps.fonttype"] = 42

COLORS = {
    "backbone": "#2E6FB0",
    "pre_sensitive": "#C0392B",
    "post_persistent": "#6A51A3",
    "post_descendant": "#6A51A3",
    "post_continuation": "#1B4F8A",
    "post_emergent": "#E58F2C",
    "root": "#2CA25F",
    "mrca": "#7F8C8D",
    "affinity": "#E58F2C",
    "clonal_arm": "#b8bec6",
}

DEFAULT_TAU = 0.8
LENGTH_SCALE = 55.0
CNV_X_SCALE = 0.14
X_DIVIDER = 300.0
PRE_CLONAL_ARM_MIN = 42.0
PRE_CLONAL_ARM_MAX = 210.0
PRE_Y_SPACING = 0.62
POST_Y_SPACING = 0.85
X_ROOT = 28.0
PAIR_CHANGE_X_SCALE = 0.06
POST_EMERGENT_CNS = "#B8956A"  # muted bronze; CNS-style (less saturated than orange)
DIVIDER_LABEL = "treatment"

PRE_MARKER = "^"
POST_MARKER = "o"
PRE_EDGE = "#000000"
POST_EDGE = "#C0392B"
MARKER_SIZE_PRE = 72
MARKER_SIZE_POST = 65


def draw_pre_fate_node(ax, xp: float, y: float, *, persistent: bool, zorder: int = 5) -> str:
    color = COLORS["backbone"] if persistent else COLORS["pre_sensitive"]
    ax.scatter(
        [xp],
        [y],
        s=MARKER_SIZE_PRE,
        marker=PRE_MARKER,
        c=color,
        edgecolors=PRE_EDGE,
        linewidths=1.2,
        zorder=zorder,
    )
    return color


def draw_post_fate_node(ax, xp: float, y: float, *, emergent: bool, zorder: int = 6) -> str:
    color = COLORS["post_emergent"] if emergent else COLORS["post_persistent"]
    ax.scatter(
        [xp],
        [y],
        s=MARKER_SIZE_POST,
        marker=POST_MARKER,
        c=color,
        edgecolors=POST_EDGE,
        linewidths=1.2,
        zorder=zorder,
    )
    return color


def fate_legend_handles() -> list:
    return [
        plt.Line2D(
            [0],
            [0],
            marker=PRE_MARKER,
            color="w",
            markerfacecolor=COLORS["backbone"],
            markeredgecolor=PRE_EDGE,
            markeredgewidth=1.2,
            markersize=9,
            label="Pre persistent",
            linestyle="None",
        ),
        plt.Line2D(
            [0],
            [0],
            marker=PRE_MARKER,
            color="w",
            markerfacecolor=COLORS["pre_sensitive"],
            markeredgecolor=PRE_EDGE,
            markeredgewidth=1.2,
            markersize=9,
            label="Pre eradicated",
            linestyle="None",
        ),
        plt.Line2D(
            [0],
            [0],
            marker=POST_MARKER,
            color="w",
            markerfacecolor=COLORS["post_persistent"],
            markeredgecolor=POST_EDGE,
            markeredgewidth=1.2,
            markersize=9,
            label="Post persistent",
            linestyle="None",
        ),
        plt.Line2D(
            [0],
            [0],
            marker=POST_MARKER,
            color="w",
            markerfacecolor=COLORS["post_emergent"],
            markeredgecolor=POST_EDGE,
            markeredgewidth=1.2,
            markersize=9,
            label="Post emergent",
            linestyle="None",
        ),
    ]


def save_figure(fig, out_prefix: Path, *, dpi: int = 150) -> None:
    """Save PNG + PDF; PDF uses TrueType fonts for Adobe editability."""
    fig.savefig(f"{out_prefix}.png", facecolor="white", bbox_inches="tight", dpi=dpi)
    fig.savefig(
        f"{out_prefix}.pdf",
        facecolor="white",
        bbox_inches="tight",
        metadata={"Creator": "plot_chemo_containment_lineage_tree.py"},
    )


def parse_args():
    default_root = os.environ.get("AXIS_REPO_ROOT") or os.getcwd()
    ap = argparse.ArgumentParser(
        description="Plot SPI / containment lineage trees (pre→post)."
    )
    ap.add_argument("--project-dir", default=default_root)
    ap.add_argument("--out-dir", default="results/SPI_lineage")
    ap.add_argument("--matrix", default="02_containment_clonal_only_pre_to_post.tsv")
    ap.add_argument("--events", default="01_clone_event_counts.tsv")
    ap.add_argument("--directed-events", default="01_directed_events_by_clone.tsv")
    ap.add_argument("--truncal-events", default="01_truncal_directed_events.tsv")
    ap.add_argument("--event-matrix", default="01_event_by_clone_matrix.tsv")
    ap.add_argument(
        "--cna-source",
        choices=("auto", "bin_matrix", "directed"),
        default="auto",
        help="auto: directed if present else bin matrix; bin_matrix: force 01_event_by_clone_matrix.tsv",
    )
    ap.add_argument("--tau", type=float, default=DEFAULT_TAU)
    ap.add_argument("--min-pre-events", type=int, default=0)
    ap.add_argument(
        "--divider-label",
        default=DIVIDER_LABEL,
        help="Vertical divider label between pre and post (e.g. treatment, CAPOX)",
    )
    ap.add_argument(
        "--post-arm-modes",
        default="containment,pair_events",
        help="Comma-separated post-arm modes: containment (L=1-C) and/or pair_events (|E_pre △ E_post|)",
    )
    return ap.parse_args()


def load_matrix(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t", index_col=0).apply(pd.to_numeric, errors="coerce")


def load_event_counts(path: Path) -> pd.Series:
    df = pd.read_csv(path, sep="\t")
    return df.set_index("clone_id")["n_events"].astype(int)


def load_clonal_from_event_matrix(
    matrix_path: Path, pre_ids: list[str] | None = None
) -> tuple[int, dict[str, int]]:
    """Bin-level event matrix: truncal = bins shared by all clones."""
    mat = pd.read_csv(matrix_path, sep="\t", index_col=0).apply(pd.to_numeric, errors="coerce").fillna(0)
    truncal_mask = (mat >= 1).all(axis=1)
    n_truncal = int(truncal_mask.sum())
    wanted = set(pre_ids) if pre_ids is not None else set(map(str, mat.columns))
    clonal: dict[str, int] = {}
    for clone_id in mat.columns:
        cid = str(clone_id)
        if cid not in wanted:
            continue
        n_total = int((mat[clone_id] >= 1).sum())
        clonal[cid] = n_total - n_truncal
    return n_truncal, clonal


def load_clonal_cna_counts(
    out_dir: Path,
    directed: str,
    truncal: str,
    event_matrix: str,
    cna_source: str = "auto",
    pre_ids: list[str] | None = None,
) -> tuple[int, dict[str, int]]:
    """Return truncal CNA count and per-pre clonal-only CNA counts."""
    mat_path = out_dir / event_matrix
    trunc_path = out_dir / truncal
    ev_path = out_dir / directed

    def _from_directed() -> tuple[int, dict[str, int]]:
        truncal_ids = set(pd.read_csv(trunc_path, sep="\t")["event_id"])
        n_truncal = len(truncal_ids)
        ev = pd.read_csv(ev_path, sep="\t")
        clonal: dict[str, int] = {}
        for clone_id, grp in ev.groupby("clone_id"):
            cid = str(clone_id)
            if pre_ids is not None and cid not in pre_ids:
                continue
            clonal[cid] = len(set(grp["event_id"]) - truncal_ids)
        return n_truncal, clonal

    if cna_source == "bin_matrix":
        if not mat_path.exists():
            raise FileNotFoundError(f"Bin event matrix not found: {mat_path}")
        return load_clonal_from_event_matrix(mat_path, pre_ids=pre_ids)

    if cna_source == "directed":
        if not (trunc_path.exists() and ev_path.exists()):
            raise FileNotFoundError(f"Directed CNA tables not found under {out_dir}")
        return _from_directed()

    # auto: directed if both exist, else bin matrix
    if trunc_path.exists() and ev_path.exists():
        return _from_directed()

    if mat_path.exists():
        return load_clonal_from_event_matrix(mat_path, pre_ids=pre_ids)

    raise FileNotFoundError(
        f"Need directed+truncal tables or {event_matrix} under {out_dir}"
    )


def cnv_to_dx(n_events: int) -> float:
    return float(n_events) * CNV_X_SCALE


def pre_x_from_clonal(
    n_clonal: int,
    clonal_min: int,
    clonal_max: int,
    x_mrca: float,
) -> float:
    """Map clonal CNA count to horizontal arm length (internally proportional)."""
    if clonal_max <= clonal_min:
        frac = 1.0
    else:
        frac = (n_clonal - clonal_min) / (clonal_max - clonal_min)
    arm = PRE_CLONAL_ARM_MIN + frac * (PRE_CLONAL_ARM_MAX - PRE_CLONAL_ARM_MIN)
    return x_mrca + arm


def compute_reverse_c(d: pd.DataFrame, nE: pd.Series) -> pd.DataFrame:
    rev = pd.DataFrame(index=d.columns, columns=d.index, dtype=float)
    for pre in d.index:
        for post in d.columns:
            if pre not in nE.index or post not in nE.index:
                continue
            inter = float(d.loc[pre, post]) * int(nE[pre])
            rev.loc[post, pre] = inter / int(nE[post])
    return rev


def pre_status(d: pd.DataFrame, tau: float) -> dict[str, str]:
    return {
        p: ("survivor" if float(d.loc[p].max()) >= tau else "sensitive")
        for p in d.index
    }


def build_backbone(pre_ids: list[str], d: pd.DataFrame, status: dict[str, str]) -> list[str]:
    surv = [p for p in pre_ids if status[p] == "survivor"]
    surv.sort(key=lambda p: (-float(d.loc[p].mean()), p))
    return surv


def assign_post_parents(
    d: pd.DataFrame, nE: pd.Series, pre_ids: list[str], post_ids: list[str], tau: float
) -> dict[str, str | None]:
    parent: dict[str, str | None] = {}
    for post in post_ids:
        cands = [
            pre
            for pre in pre_ids
            if int(nE[pre]) < int(nE[post]) and float(d.loc[pre, post]) >= tau
        ]
        parent[post] = max(cands, key=lambda p: float(d.loc[p, post])) if cands else None
    return parent


def classify_link(
    pre: str | None,
    post: str,
    d: pd.DataFrame,
    rev: pd.DataFrame,
    tau: float,
) -> str:
    if pre is None:
        return "emergent"
    cf = float(d.loc[pre, post])
    cr = float(rev.loc[post, pre])
    if cf < tau:
        return "emergent"
    if cr >= tau:
        return "continuation"
    return "descendant"


def c_link_style(c: float, c_min: float, c_max: float) -> tuple[str, float, float]:
    """Map containment C to purple shade (dark=high C) and line width (thick=high C)."""
    if c_max <= c_min:
        t = 1.0
    else:
        t = (c - c_min) / (c_max - c_min)
    t = float(np.clip(t, 0.0, 1.0))
    dark = np.array([0.24, 0.16, 0.40])
    light = np.array([0.86, 0.80, 0.93])
    rgb = dark * t + light * (1.0 - t)
    color = "#{:02x}{:02x}{:02x}".format(int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255))
    lw = 0.8 + t * 2.4
    alpha = 0.55 + t * 0.40
    return color, lw, alpha


def collect_high_c_pairs(d: pd.DataFrame, tau: float) -> list[tuple[str, str, float]]:
    pairs: list[tuple[str, str, float]] = []
    for pre in d.index:
        for post in d.columns:
            c = float(d.loc[pre, post])
            if c > tau:
                pairs.append((str(pre), str(post), c))
    pairs.sort(key=lambda x: x[2])
    return pairs


def draw_tree_scaffold(
    ax,
    *,
    pre_ids: list[str],
    post_ids: list[str],
    y_pre: dict[str, float],
    y_post: dict[str, float],
    x_pre: dict[str, float],
    x_mrca: float,
    n_truncal: int,
    status: dict[str, str],
    clonal_counts: dict[str, int],
    d: pd.DataFrame,
    nE: pd.Series,
    y_pre_center: float,
    y_all: list[float],
    y_pad: float,
    divider_label: str = DIVIDER_LABEL,
):
    ax.set_xlim(8, 400)
    ax.set_ylim(min(y_all) - y_pad, max(y_all) + y_pad)
    ax.axis("off")

    ax.axvline(X_DIVIDER, color="#9aa3ad", ls=(0, (4, 4)), lw=1.4, zorder=0)
    y_label = min(y_all) - y_pad + 0.3
    ax.text(X_DIVIDER, y_label, divider_label, ha="center", fontsize=10, color="#6b7280")
    ax.text((x_mrca + max(x_pre.values())) / 2, y_label, "pre-chemo", ha="center", fontsize=9, color="#8a929c")
    ax.text((X_DIVIDER + 360) / 2, y_label, "post-chemo", ha="center", fontsize=9, color="#8a929c")

    ax.plot([X_ROOT, x_mrca], [y_pre_center, y_pre_center], color="#b0b6bd", lw=2.2, zorder=1)
    ax.scatter([X_ROOT], [y_pre_center], s=52, color=COLORS["root"], edgecolors="white", lw=1.2, zorder=5)
    ax.text(X_ROOT, y_pre_center - 0.42, "diploid", ha="center", fontsize=7.5, color="#6b7280")
    ax.scatter(
        [x_mrca], [y_pre_center], s=58, facecolors="none", edgecolors=COLORS["mrca"], lw=2.0, zorder=5
    )
    ax.text(x_mrca, y_pre_center + 0.48, "MRCA", ha="center", fontsize=7.5, color="#6b7280")
    ax.text(
        (X_ROOT + x_mrca) / 2,
        y_pre_center + 0.38,
        f"{n_truncal} truncal CNA",
        ha="center",
        va="bottom",
        fontsize=5.8,
        color="#6b7280",
        fontweight="bold",
    )

    for pre in pre_ids:
        y = y_pre[pre]
        xp = x_pre[pre]
        max_c = float(d.loc[pre].max())
        n_clonal = clonal_counts.get(pre, 0)
        draw_bezier(
            ax,
            (x_mrca, y_pre_center),
            (xp, y),
            color=COLORS["clonal_arm"],
            lw=1.5,
            ls=(0, (4, 3)),
            alpha=0.9,
        )
        xm = (x_mrca + xp) / 2.0
        ym = (y_pre_center + y) / 2.0
        ax.text(
            xm,
            ym + 0.22,
            f"{n_clonal} clonal",
            ha="center",
            va="bottom",
            fontsize=5.5,
            color="#6b7280",
        )
        color = draw_pre_fate_node(ax, xp, y, persistent=(status[pre] == "survivor"))
        ax.text(
            xp - 6, y, f"{pre}\nCmax={max_c:.3f}",
            ha="right", va="center", fontsize=6.2, color=color, fontweight="bold",
        )


def plot_all_high_c_tree(
    d: pd.DataFrame,
    nE: pd.Series,
    status: dict[str, str],
    out_prefix: Path,
    tau: float,
    n_truncal: int,
    clonal_counts: dict[str, int],
    dataset_label: str = "",
    divider_label: str = DIVIDER_LABEL,
):
    pre_ids = order_pre_ids(list(d.index), status, d)
    post_ids = order_post_ids(list(d.columns))
    y_pre = equal_y_positions(pre_ids, spacing=PRE_Y_SPACING)
    y_post = equal_y_positions(post_ids, spacing=POST_Y_SPACING)

    x_mrca = X_ROOT + cnv_to_dx(n_truncal)
    clonal_vals = [clonal_counts.get(p, 0) for p in pre_ids]
    clonal_min, clonal_max = min(clonal_vals), max(clonal_vals)
    x_pre = {
        p: pre_x_from_clonal(clonal_counts.get(p, 0), clonal_min, clonal_max, x_mrca)
        for p in pre_ids
    }

    pairs = collect_high_c_pairs(d, tau)
    if not pairs:
        raise ValueError(f"No pre-post pairs with C > {tau}")

    c_min = min(c for _, _, c in pairs)
    c_max = max(c for _, _, c in pairs)
    link_rows: list[dict] = []

    pre_span = max((len(pre_ids) - 1) * PRE_Y_SPACING, 1.0)
    post_span = max((len(post_ids) - 1) * POST_Y_SPACING, 1.0)
    fig_h = max(10.0, max(pre_span, post_span) * 0.52 + 2.5)
    fig, ax = plt.subplots(figsize=(14.0, fig_h), dpi=150)

    y_all = list(y_pre.values()) + list(y_post.values())
    y_pad = 1.4
    y_pre_center = float(np.mean(list(y_pre.values())))
    draw_tree_scaffold(
        ax,
        pre_ids=pre_ids,
        post_ids=post_ids,
        y_pre=y_pre,
        y_post=y_post,
        x_pre=x_pre,
        x_mrca=x_mrca,
        n_truncal=n_truncal,
        status=status,
        clonal_counts=clonal_counts,
        d=d,
        nE=nE,
        y_pre_center=y_pre_center,
        y_all=y_all,
        y_pad=y_pad,
        divider_label=divider_label,
    )

    post_best_pre: dict[str, tuple[str, float]] = {}
    for pre, post, c in pairs:
        if post not in post_best_pre or c > post_best_pre[post][1]:
            post_best_pre[post] = (pre, c)

    for pre, post, c in pairs:
        metrics = pair_change_metrics(pre, post, d, nE)
        xp = x_post_arm(pre, post, d, nE, post_arm_mode="pair_events", cf=c)
        color, lw, alpha = c_link_style(c, c_min, c_max)
        draw_bezier(
            ax,
            (x_pre[pre], y_pre[pre]),
            (xp, y_post[post]),
            color=color,
            lw=lw,
            ls="-",
            alpha=alpha,
            zorder=3,
        )
        link_rows.append(
            {
                "pre": pre,
                "post": post,
                "C_fwd": c,
                **metrics,
                "relation": "high_c_pair",
            }
        )

    for post in post_ids:
        if post not in post_best_pre:
            best_pre = d[post].idxmax()
            cf = float(d.loc[best_pre, post])
            metrics = pair_change_metrics(best_pre, post, d, nE)
            xp = x_post_arm(best_pre, post, d, nE, post_arm_mode="pair_events", cf=cf)
            draw_bezier(
                ax,
                (x_pre[best_pre], y_pre[best_pre]),
                (xp, y_post[post]),
                color=COLORS["affinity"],
                lw=1.4,
                ls=(0, (2, 2, 6, 2)),
                alpha=0.85,
                zorder=2,
            )
            link_rows.append(
                {
                    "pre": best_pre,
                    "post": post,
                    "C_fwd": cf,
                    **metrics,
                    "relation": "emergent_best",
                }
            )

    for post in post_ids:
        is_emergent = post not in post_best_pre
        if is_emergent:
            best_pre = d[post].idxmax()
            cf = float(d.loc[best_pre, post])
            metrics = pair_change_metrics(best_pre, post, d, nE)
            xp = x_post_arm(best_pre, post, d, nE, post_arm_mode="pair_events", cf=cf)
        else:
            best_pre, cf = post_best_pre[post]
            metrics = pair_change_metrics(best_pre, post, d, nE)
            xp = x_post_arm(best_pre, post, d, nE, post_arm_mode="pair_events", cf=cf)
        label = f"{post}\n|△|={metrics['n_symdiff']}\nCmax={post_cmax(d, post):.3f}"
        node_color = draw_post_fate_node(ax, xp, y_post[post], emergent=is_emergent)
        ax.text(
            xp + 8,
            y_post[post],
            label,
            ha="left",
            va="center",
            fontsize=6.0,
            color=node_color,
            fontweight="bold",
        )

    subtitle = (
        f"tau={tau:.2f}; all C>{tau:.2f} pre-post links; "
        f"arm=|E_pre △ E_post|; color/width ∝ C (dark/thick=high)"
    )
    if dataset_label:
        subtitle = f"{dataset_label}\n{subtitle}"
    ax.set_title(
        f"Containment lineage tree — all high-C pairs (clonal-only)\n{subtitle}",
        fontsize=11,
        fontweight="bold",
        pad=12,
    )

    legend_handles = fate_legend_handles()
    c_dark, lw_dark, _ = c_link_style(c_max, c_min, c_max)
    c_light, lw_light, _ = c_link_style(c_min, c_min, c_max)
    legend_handles.extend([
        plt.Line2D([0], [0], color=c_dark, lw=lw_dark, ls="-", label=f"High C (~{c_max:.2f})"),
        plt.Line2D([0], [0], color=c_light, lw=lw_light, ls="-", label=f"Low C (~{c_min:.2f})"),
    ])
    ax.legend(handles=legend_handles, loc="upper left", fontsize=8.0, frameon=False)

    fig.tight_layout()
    save_figure(fig, out_prefix)
    plt.close(fig)
    return link_rows


def draw_bezier(ax, p0, p1, *, color, lw, ls, alpha=1.0, zorder=2):
    x0, y0 = p0
    x1, y1 = p1
    xm = (x0 + x1) / 2.0
    verts = [(x0, y0), (xm, y0), (xm, y1), (x1, y1)]
    codes = [MplPath.MOVETO, MplPath.CURVE4, MplPath.CURVE4, MplPath.CURVE4]
    ax.add_patch(
        mpatches.PathPatch(
            MplPath(verts, codes),
            facecolor="none",
            edgecolor=color,
            linewidth=lw,
            linestyle=ls,
            alpha=alpha,
            capstyle="round",
            zorder=zorder,
        )
    )



def order_pre_ids(pre_ids: list[str], status: dict[str, str], d: pd.DataFrame) -> list[str]:
    survivors = [p for p in pre_ids if status[p] == "survivor"]
    sensitive = [p for p in pre_ids if status[p] == "sensitive"]
    survivors.sort(key=lambda p: (-float(d.loc[p].max()), p))
    sensitive.sort(key=lambda p: (-float(d.loc[p].max()), p))
    return survivors + sensitive


def order_post_ids(post_ids: list[str]) -> list[str]:
    def key(q: str):
        parts = q.split("_")
        try:
            return (int(parts[1]), int(parts[2][1:]), q)
        except (IndexError, ValueError):
            return (999, 999, q)

    return sorted(post_ids, key=key)


def equal_y_positions(ids: list[str], spacing: float = 1.0) -> dict[str, float]:
    n = len(ids)
    return {cid: (i - (n - 1) / 2.0) * spacing for i, cid in enumerate(ids)}


def x_from_pre(d: pd.DataFrame, pre: str) -> float:
    max_c = float(d.loc[pre].max())
    return X_DIVIDER - (1.0 - max_c) * LENGTH_SCALE


def x_from_link(c: float) -> float:
    return X_DIVIDER + (1.0 - c) * LENGTH_SCALE


def pair_intersection_events(pre: str, post: str, d: pd.DataFrame, nE: pd.Series) -> int:
    """|E_pre ∩ E_post| = C(pre→post) × |E_pre|."""
    return int(round(float(d.loc[pre, post]) * int(nE[pre])))


def pair_pre_lost_events(pre: str, post: str, d: pd.DataFrame, nE: pd.Series) -> int:
    """|E_pre \\ E_post|."""
    return int(nE[pre]) - pair_intersection_events(pre, post, d, nE)


def pair_post_gain_events(pre: str, post: str, d: pd.DataFrame, nE: pd.Series) -> int:
    """|E_post \\ E_pre|."""
    return int(nE[post]) - pair_intersection_events(pre, post, d, nE)


def pair_symmetric_diff_events(pre: str, post: str, d: pd.DataFrame, nE: pd.Series) -> int:
    """|E_pre △ E_post| = pre lost + post gained."""
    return pair_pre_lost_events(pre, post, d, nE) + pair_post_gain_events(pre, post, d, nE)


def pair_change_metrics(pre: str, post: str, d: pd.DataFrame, nE: pd.Series) -> dict[str, int]:
    n_inter = pair_intersection_events(pre, post, d, nE)
    n_lost = int(nE[pre]) - n_inter
    n_gain = int(nE[post]) - n_inter
    return {
        "n_intersection": n_inter,
        "n_pre_lost": n_lost,
        "n_post_gain": n_gain,
        "n_symdiff": n_lost + n_gain,
    }


def x_post_arm(
    pre: str,
    post: str,
    d: pd.DataFrame,
    nE: pd.Series,
    *,
    post_arm_mode: str,
    cf: float | None = None,
) -> float:
    if post_arm_mode == "pair_events":
        n_change = pair_symmetric_diff_events(pre, post, d, nE)
        return X_DIVIDER + float(n_change) * PAIR_CHANGE_X_SCALE
    c = cf if cf is not None else float(d.loc[pre, post])
    return x_from_link(c)


def post_arm_subtitle(post_arm_mode: str) -> str:
    if post_arm_mode == "pair_events":
        return "right arms: |E_pre △ E_post| = loss+gain (scaled)"
    return "right arms: L=1-C (scaled)"


def post_cmax(d: pd.DataFrame, post: str) -> float:
    return float(d[post].max())


def post_arm_label(
    post: str,
    cf: float,
    metrics: dict[str, int],
    post_arm_mode: str,
    rel: str,
    cr: float,
    d: pd.DataFrame,
) -> str:
    if rel == "continuation":
        return f"{post}\ncont {cf:.2f}/{cr:.2f}"
    if post_arm_mode == "pair_events":
        return f"{post}\n|△|={metrics['n_symdiff']}\nCmax={post_cmax(d, post):.3f}"
    return f"{post}\nC={cf:.3f}"


def plot_nested_tree(
    d: pd.DataFrame,
    rev: pd.DataFrame,
    nE: pd.Series,
    status: dict[str, str],
    backbone: list[str],
    post_parent: dict[str, str | None],
    out_prefix: Path,
    tau: float,
    n_truncal: int,
    clonal_counts: dict[str, int],
    dataset_label: str = "",
    post_arm_mode: str = "containment",
    divider_label: str = DIVIDER_LABEL,
):
    del backbone

    pre_ids = order_pre_ids(list(d.index), status, d)
    post_ids = order_post_ids(list(d.columns))
    y_pre = equal_y_positions(pre_ids, spacing=PRE_Y_SPACING)
    y_post = equal_y_positions(post_ids, spacing=POST_Y_SPACING)

    x_mrca = X_ROOT + cnv_to_dx(n_truncal)
    clonal_vals = [clonal_counts.get(p, 0) for p in pre_ids]
    clonal_min, clonal_max = min(clonal_vals), max(clonal_vals)
    x_pre = {
        p: pre_x_from_clonal(clonal_counts.get(p, 0), clonal_min, clonal_max, x_mrca)
        for p in pre_ids
    }
    x_post_node: dict[str, float] = {}
    pre_outgoing: set[str] = set()

    link_rows: list[dict] = []

    pre_span = max((len(pre_ids) - 1) * PRE_Y_SPACING, 1.0)
    post_span = max((len(post_ids) - 1) * POST_Y_SPACING, 1.0)
    fig_h = max(10.0, max(pre_span, post_span) * 0.52 + 2.5)
    fig, ax = plt.subplots(figsize=(14.0, fig_h), dpi=150)

    y_all = list(y_pre.values()) + list(y_post.values())
    y_pad = 1.4
    y_pre_center = float(np.mean(list(y_pre.values())))
    ax.set_xlim(8, 400)
    ax.set_ylim(min(y_all) - y_pad, max(y_all) + y_pad)
    ax.axis("off")

    ax.axvline(X_DIVIDER, color="#9aa3ad", ls=(0, (4, 4)), lw=1.4, zorder=0)
    y_label = min(y_all) - y_pad + 0.3
    ax.text(X_DIVIDER, y_label, divider_label, ha="center", fontsize=10, color="#6b7280")
    ax.text((x_mrca + max(x_pre.values())) / 2, y_label, "pre-chemo", ha="center", fontsize=9, color="#8a929c")
    ax.text((X_DIVIDER + 360) / 2, y_label, "post-chemo", ha="center", fontsize=9, color="#8a929c")

    # diploid -> MRCA: length proportional to truncal CNA count
    ax.plot([X_ROOT, x_mrca], [y_pre_center, y_pre_center], color="#b0b6bd", lw=2.2, zorder=1)
    ax.scatter([X_ROOT], [y_pre_center], s=52, color=COLORS["root"], edgecolors="white", lw=1.2, zorder=5)
    ax.text(X_ROOT, y_pre_center - 0.42, "diploid", ha="center", fontsize=7.5, color="#6b7280")
    ax.scatter(
        [x_mrca], [y_pre_center], s=58, facecolors="none", edgecolors=COLORS["mrca"], lw=2.0, zorder=5
    )
    ax.text(x_mrca, y_pre_center + 0.48, "MRCA", ha="center", fontsize=7.5, color="#6b7280")
    ax.text(
        (X_ROOT + x_mrca) / 2,
        y_pre_center + 0.38,
        f"{n_truncal} truncal CNA",
        ha="center",
        va="bottom",
        fontsize=5.8,
        color="#6b7280",
        fontweight="bold",
    )

    # Pre nodes: MRCA -> pre dashed curve; arm length proportional to clonal CNA count
    for pre in pre_ids:
        y = y_pre[pre]
        xp = x_pre[pre]
        max_c = float(d.loc[pre].max())
        n_clonal = clonal_counts.get(pre, 0)
        color = COLORS["backbone"] if status[pre] == "survivor" else COLORS["pre_sensitive"]

        draw_bezier(
            ax,
            (x_mrca, y_pre_center),
            (xp, y),
            color=COLORS["clonal_arm"],
            lw=1.5,
            ls=(0, (4, 3)),
            alpha=0.9,
        )
        xm = (x_mrca + xp) / 2.0
        ym = (y_pre_center + y) / 2.0
        ax.text(
            xm,
            ym + 0.22,
            f"{n_clonal} clonal",
            ha="center",
            va="bottom",
            fontsize=5.5,
            color="#6b7280",
        )

        color = draw_pre_fate_node(ax, xp, y, persistent=(status[pre] == "survivor"))
        ax.text(xp - 6, y, f"{pre}\nCmax={max_c:.3f}", ha="right", va="center", fontsize=6.2,
                color=color, fontweight="bold")

    # Post nodes and links
    for post in post_ids:
        parent = post_parent[post]
        rel = classify_link(parent, post, d, rev, tau)
        y = y_post[post]

        if rel == "emergent" or parent is None:
            best_pre = d[post].idxmax()
            cf = float(d.loc[best_pre, post])
            metrics = pair_change_metrics(best_pre, post, d, nE)
            xp = x_post_arm(best_pre, post, d, nE, post_arm_mode=post_arm_mode, cf=cf)
            x_post_node[post] = xp
            draw_bezier(
                ax,
                (x_pre[best_pre], y_pre[best_pre]),
                (xp, y),
                color=COLORS["affinity"],
                lw=1.4,
                ls=(0, (2, 2, 6, 2)),
                alpha=0.85,
            )
            pre_outgoing.add(best_pre)
            is_emergent = True
            label = post_arm_label(post, cf, metrics, post_arm_mode, "emergent", np.nan, d)
            link_rows.append(
                {
                    "pre": best_pre,
                    "post": post,
                    "C_fwd": cf,
                    "C_rev": np.nan,
                    **metrics,
                    "relation": "emergent_best",
                }
            )
        else:
            cf = float(d.loc[parent, post])
            cr = float(rev.loc[post, parent])
            metrics = pair_change_metrics(parent, post, d, nE)
            xp = x_post_arm(parent, post, d, nE, post_arm_mode=post_arm_mode, cf=cf)
            x_post_node[post] = xp
            link_color = COLORS["post_persistent"]
            lw = 3.0 if rel == "continuation" else (2.6 if cf >= 0.85 else 2.0)
            draw_bezier(
                ax,
                (x_pre[parent], y_pre[parent]),
                (xp, y),
                color=link_color,
                lw=lw,
                ls="-",
                alpha=1.0,
            )
            pre_outgoing.add(parent)
            is_emergent = False
            label = post_arm_label(post, cf, metrics, post_arm_mode, rel, cr, d)
            link_rows.append(
                {
                    "pre": parent,
                    "post": post,
                    "C_fwd": cf,
                    "C_rev": cr,
                    **metrics,
                    "relation": rel,
                }
            )

        node_color = draw_post_fate_node(ax, xp, y, emergent=is_emergent)
        ax.text(xp + 8, y, label, ha="left", va="center", fontsize=6.0, color=node_color, fontweight="bold")

    # Orphan pre survivors: no outgoing link yet -> connect to Cmax post (teal solid)
    for pre in pre_ids:
        if status[pre] != "survivor" or pre in pre_outgoing:
            continue
        best_post = d.loc[pre].idxmax()
        cf = float(d.loc[pre, best_post])
        metrics = pair_change_metrics(pre, best_post, d, nE)
        y0, y1 = y_pre[pre], y_post[best_post]
        if post_arm_mode == "pair_events":
            x1 = x_post_arm(pre, best_post, d, nE, post_arm_mode=post_arm_mode, cf=cf)
        elif best_post in x_post_node:
            x1 = x_post_node[best_post]
        else:
            x1 = x_post_arm(pre, best_post, d, nE, post_arm_mode=post_arm_mode, cf=cf)
            x_post_node[best_post] = x1
        draw_bezier(
            ax,
            (x_pre[pre], y0),
            (x1, y1),
            color=COLORS["post_descendant"],
            lw=2.0,
            ls=(0, (4, 2)),
            alpha=0.95,
        )
        link_rows.append(
            {
                "pre": pre,
                "post": best_post,
                "C_fwd": cf,
                "C_rev": np.nan,
                **metrics,
                "relation": "survivor_cmax_best",
            }
        )

    subtitle = f"tau={tau:.2f}; left arms: clonal CNA; {post_arm_subtitle(post_arm_mode)}"
    if dataset_label:
        subtitle = f"{dataset_label}\n{subtitle}"
    ax.set_title(
        f"Containment lineage tree (clonal-only)\n{subtitle}",
        fontsize=11,
        fontweight="bold",
        pad=12,
    )

    ax.legend(handles=fate_legend_handles(), loc="upper left", fontsize=8.0, frameon=False)

    fig.tight_layout()
    save_figure(fig, out_prefix)
    plt.close(fig)
    return link_rows


def write_outputs(
    out_prefix: Path,
    d: pd.DataFrame,
    rev: pd.DataFrame,
    backbone: list[str],
    post_parent: dict[str, str | None],
    status: dict[str, str],
    link_rows: list[dict],
    clonal_counts: dict[str, int],
    n_truncal: int,
    tau: float,
    cna_source: str,
):
    rev.to_csv(f"{out_prefix}_reverse_c.tsv", sep="\t")
    pd.DataFrame({"backbone_order": backbone}).to_csv(f"{out_prefix}_backbone.tsv", sep="\t", index=False)
    pd.DataFrame(
        [{"post": q, "parent_pre": post_parent[q]} for q in d.columns]
    ).to_csv(f"{out_prefix}_post_parents.tsv", sep="\t", index=False)
    pd.DataFrame(link_rows).to_csv(f"{out_prefix}_links.tsv", sep="\t", index=False)
    pd.DataFrame(
        [
            {
                "pre_clone": p,
                "status": status[p],
                "n_truncal_shared": n_truncal,
                "n_clonal_cna": clonal_counts.get(p, 0),
                "mean_C": float(d.loc[p].mean()),
                "max_C": float(d.loc[p].max()),
            }
            for p in d.index
        ]
    ).to_csv(f"{out_prefix}_pre_summary.tsv", sep="\t", index=False)
    pd.DataFrame([{"n_truncal_cna": n_truncal, "cna_source": cna_source}]).to_csv(
        f"{out_prefix}_truncal_cna.tsv", sep="\t", index=False
    )


def main():
    args = parse_args()
    out_dir = Path(args.out_dir)
    if not out_dir.is_absolute():
        out_dir = Path(args.project_dir) / out_dir
    out_dir = out_dir.resolve()
    d = load_matrix(out_dir / args.matrix)
    nE = load_event_counts(out_dir / args.events)

    if args.min_pre_events > 0:
        drop = [p for p in d.index if int(nE.get(p, 0)) < args.min_pre_events]
        if drop:
            d = d.drop(index=drop)
            print(f"Dropped pre clones with |E| < {args.min_pre_events}: {drop}")

    rev = compute_reverse_c(d, nE)
    status = pre_status(d, args.tau)
    backbone = build_backbone(list(d.index), d, status)
    post_parent = assign_post_parents(d, nE, list(d.index), list(d.columns), args.tau)

    n_truncal, clonal_counts = load_clonal_cna_counts(
        out_dir,
        args.directed_events,
        args.truncal_events,
        args.event_matrix,
        args.cna_source,
        pre_ids=list(map(str, d.index)),
    )

    out_prefix = out_dir / "07_containment_lineage_tree"
    if "result4" in str(out_dir):
        dataset_label = "Data: chemo_result4 · bin-level CNA · 02_containment_clonal_only (non-directional)"
    elif "directional" in str(out_dir):
        dataset_label = "Data: chemo_medicc2_directional · gain/loss CNA · 02_containment_clonal_only (directional)"
    elif "SPI" in str(out_dir):
        dataset_label = "Data: SPI lineage · clonal-only containment (directional)"
    else:
        dataset_label = str(out_dir.name)

    arm_modes = [m.strip() for m in args.post_arm_modes.split(",") if m.strip()]
    arm_prefix = {
        "containment": out_prefix,
        "pair_events": out_dir / "07_containment_lineage_tree_by_pair_events",
    }

    for mode in arm_modes:
        prefix = arm_prefix.get(mode)
        if prefix is None:
            raise ValueError(f"Unknown post-arm mode: {mode}")
        link_rows = plot_nested_tree(
            d, rev, nE, status, backbone, post_parent, prefix, args.tau, n_truncal, clonal_counts,
            dataset_label, post_arm_mode=mode, divider_label=args.divider_label,
        )
        write_outputs(
            prefix, d, rev, backbone, post_parent, status, link_rows,
            clonal_counts, n_truncal, args.tau, args.cna_source,
        )
        print(f"Saved ({mode}): {prefix}.png / .pdf")

    all_high_c_prefix = out_dir / "07_containment_lineage_tree_all_high_c"
    high_c_rows = plot_all_high_c_tree(
        d, nE, status, all_high_c_prefix, args.tau, n_truncal, clonal_counts, dataset_label,
        divider_label=args.divider_label,
    )
    pd.DataFrame(high_c_rows).to_csv(f"{all_high_c_prefix}_links.tsv", sep="\t", index=False)
    print(f"Saved (all_high_c): {all_high_c_prefix}.png / .pdf ({len(high_c_rows)} links)")

    n_em = sum(1 for q in d.columns if classify_link(post_parent[q], q, d, rev, args.tau) == "emergent")
    print(f"tau={args.tau}")
    print(f"CNA source: {args.cna_source}")
    print(f"Truncal CNA (diploid->MRCA): {n_truncal}")
    print(f"Backbone ({len(backbone)}): {', '.join(backbone)}")
    print(f"Post assigned: {sum(v is not None for v in post_parent.values())}/{len(post_parent)}")
    print(f"Emergent posts: {n_em}")


if __name__ == "__main__":
    main()
