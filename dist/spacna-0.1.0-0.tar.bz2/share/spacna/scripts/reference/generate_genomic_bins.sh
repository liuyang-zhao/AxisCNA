#!/bin/bash
# Rebuild the bundled 1 Mb genomic bins from chrom.sizes.
# For any other bin size, use: spacna gen-reference ...

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
GEN="${SCRIPT_DIR}/generate_reference.py"

echo "Rebuilding bundled 1 Mb bins under reference/genomic_bins/ ..."
python "${GEN}" --repo-root "${REPO_ROOT}" --species human --bin-size 1Mb --mode bins
python "${GEN}" --repo-root "${REPO_ROOT}" --species mouse --bin-size 1Mb --mode bins

echo "Done. Only 1 Mb references are shipped."
echo "Generate any other size after downloading the genome:"
echo "  spacna gen-reference --species human --bin-size 500kb --mode all \\"
echo "    --fasta \"\$SPACNA_HUMAN_FASTA\" --mappability-bw \"\$SPACNA_HUMAN_MAP_BW\""
