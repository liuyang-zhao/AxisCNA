#!/usr/bin/env python3
"""Generate genomic bins / GC / mappability references for an arbitrary bin size.

Examples:
  # Bins only (no external genome download needed; uses bundled chrom.sizes)
  axis-dna gen-reference --species human --bin-size 500000 --mode bins

  # Full reference after downloading FASTA + mappability bigWig
  axis-dna gen-reference --species human --bin-size 100000 --mode all \\
    --fasta "$SPACNA_HUMAN_FASTA" --mappability-bw "$SPACNA_HUMAN_MAP_BW"

  # Mouse 250 kb
  axis-dna gen-reference --species mouse --bin-size 250000 --mode all \\
    --fasta "$SPACNA_MOUSE_FASTA" --mappability-bw "$SPACNA_MOUSE_MAP_BW"
"""

from __future__ import annotations

import argparse
import math
import os
import re
import subprocess
import sys

try:
    import natsort as _natsort

    def _natsorted(xs):
        return list(_natsort.natsorted(xs))
except ImportError:
    def _natsorted(xs):
        def key(s):
            return [int(t) if t.isdigit() else t.lower() for t in re.split(r"([0-9]+)", s)]
        return sorted(xs, key=key)

try:
    import pysam
except ImportError:
    pysam = None  # type: ignore


def format_bin_label(bin_size: int) -> str:
    if bin_size % 1_000_000 == 0:
        return f"{bin_size // 1_000_000}Mb"
    # e.g. 2.5 Mb
    if bin_size >= 1_000_000 and bin_size % 100_000 == 0:
        val = bin_size / 1_000_000
        text = f"{val:.1f}".rstrip("0").rstrip(".")
        return f"{text}Mb"
    if bin_size % 1000 == 0:
        return f"{bin_size // 1000}kb"
    return f"{bin_size}bp"


def parse_bin_size(text: str) -> int:
    """Accept 1000000, 1Mb, 500kb, 250000, etc."""
    s = text.strip().lower().replace("_", "")
    if s.endswith("mb"):
        return int(float(s[:-2]) * 1_000_000)
    if s.endswith("kb"):
        return int(float(s[:-2]) * 1000)
    if s.endswith("bp"):
        return int(s[:-2])
    return int(s)


def species_genome_tag(species: str) -> tuple[str, str]:
    species = species.lower()
    if species == "human":
        return "GRCh38", "hg38"
    if species == "mouse":
        return "GRCm39", "GRCm39"
    # other species: caller should pass --genome-tag and chrom.sizes
    return species.upper(), species.lower()


def write_bins_from_chrom_sizes(chrom_sizes_path: str, bin_size: int, out_txt: str, out_bed: str | None = None) -> int:
    chrom_sizes: dict[str, int] = {}
    with open(chrom_sizes_path, encoding="utf-8") as handle:
        for line in handle:
            parts = line.rstrip().split()
            if len(parts) < 2:
                continue
            chrom, size = parts[0], parts[1]
            if "." not in chrom:
                chrom_sizes[chrom] = int(size)

    ordered = [c for c in _natsorted(chrom_sizes) if c != "chrM"]
    if "chrM" in chrom_sizes:
        ordered.append("chrM")

    n_bins = 0
    os.makedirs(os.path.dirname(out_txt) or ".", exist_ok=True)
    bed_fh = open(out_bed, "w", encoding="utf-8") if out_bed else None
    with open(out_txt, "w", encoding="utf-8") as fh:
        fh.write("\t".join(["chr", "bin_start", "bin_end", "bin_len", "chr_ind", "bin_ind"]) + "\n")
        chrom_ind = 1
        bin_ind = 1
        for chrom in ordered:
            chrom_size = chrom_sizes[chrom]
            num_bins = int(math.ceil(chrom_size / bin_size))
            for i in range(num_bins):
                bin_start = max(1, i * bin_size)
                bin_end = min(chrom_size, (i + 1) * bin_size)
                fh.write(
                    "\t".join(
                        [
                            chrom,
                            str(bin_start),
                            str(bin_end),
                            str(bin_end - bin_start),
                            str(chrom_ind),
                            str(bin_ind),
                        ]
                    )
                    + "\n"
                )
                if bed_fh is not None:
                    # BED is 0-based, end-exclusive
                    bed_fh.write(f"{chrom}\t{bin_start - 1}\t{bin_end}\n")
                bin_ind += 1
                n_bins += 1
            chrom_ind += 1
    if bed_fh is not None:
        bed_fh.close()
    return n_bins


def calculate_gc_content(fasta_file: str, bins_file: str, output_file: str) -> None:
    if pysam is None:
        raise RuntimeError("pysam is required for GC calculation. Install pysam or use conda env.")
    if not os.path.exists(fasta_file + ".fai"):
        print(f"Indexing {fasta_file} ...")
        pysam.faidx(fasta_file)
    fasta = pysam.FastaFile(fasta_file)
    os.makedirs(os.path.dirname(output_file) or ".", exist_ok=True)
    with open(bins_file, "r", encoding="utf-8") as f_in, open(output_file, "w", encoding="utf-8") as f_out:
        header = f_in.readline().rstrip("\n").split("\t")
        # Keep pipeline-compatible columns: original fields + gc_total + gc_ratio
        # Existing 1Mb GC files are headerless with gc in column 8; we write a
        # headered table and also duplicate gc_ratio as last column for R joins.
        for line in f_in:
            fields = line.strip().split("\t")
            chrom, start, end = fields[0], int(fields[1]), int(fields[2])
            # tolerate chr / no-chr in FASTA
            try:
                seq = fasta.fetch(chrom, start - 1, end)
            except KeyError:
                alt = chrom[3:] if chrom.startswith("chr") else f"chr{chrom}"
                seq = fasta.fetch(alt, start - 1, end)
            g_count = seq.upper().count("G")
            c_count = seq.upper().count("C")
            gc_total = g_count + c_count
            gc_fraction = 0.0 if len(seq) == 0 else gc_total / len(seq)
            # Match historical layout used by R: cols 1-3 + padding + gc_ratio at col 8
            # chr start end bin_len chr_ind bin_ind gc_total gc_ratio
            while len(fields) < 6:
                fields.append("NA")
            row = fields[:6] + [str(gc_total), str(gc_fraction)]
            f_out.write("\t".join(row) + "\n")
    fasta.close()
    print(f"GC content saved to {output_file}")


def calculate_mappability(bigwig_file: str, bins_file: str, output_file: str) -> None:
    if not os.path.exists(bigwig_file):
        raise FileNotFoundError(f"bigWig file not found: {bigwig_file}")
    bins_data = {}
    original_header = []
    with open(bins_file, "r", encoding="utf-8") as f_in:
        original_header = f_in.readline().strip().split("\t")
        for line in f_in:
            fields = line.strip().split("\t")
            bin_key = f"{fields[0]}:{fields[1]}-{fields[2]}"
            bins_data[bin_key] = fields

    temp_bed_file = output_file + ".tmp.bed"
    os.makedirs(os.path.dirname(output_file) or ".", exist_ok=True)
    with open(temp_bed_file, "w", encoding="utf-8") as f_out:
        for key, fields in bins_data.items():
            chrom, start, end = fields[0], int(fields[1]) - 1, int(fields[2])
            f_out.write(f"{chrom}\t{start}\t{end}\t{key}\n")

    command = ["bigWigAverageOverBed", bigwig_file, temp_bed_file, "stdout"]
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        with open(output_file, "w", encoding="utf-8") as f_out:
            new_header = original_header + ["mappability_score"]
            f_out.write("\t".join(new_header) + "\n")
            for line in result.stdout.strip().split("\n"):
                if not line.strip():
                    continue
                res_fields = line.split("\t")
                bin_key, mean_signal = res_fields[0], res_fields[4]
                if bin_key in bins_data:
                    f_out.write("\t".join(bins_data[bin_key] + [mean_signal]) + "\n")
    finally:
        if os.path.exists(temp_bed_file):
            os.remove(temp_bed_file)
    print(f"Mappability saved to {output_file}")


def parse_args():
    p = argparse.ArgumentParser(description="Generate AXIS reference tables for a bin size.")
    p.add_argument("--species", default="human", help="human | mouse | custom label")
    p.add_argument("--bin-size", required=True, help="e.g. 1000000, 1Mb, 500kb, 250000")
    p.add_argument("--mode", choices=["bins", "gc", "map", "all"], default="bins")
    p.add_argument("--repo-root", default=None)
    p.add_argument("--chrom-sizes", default=None, help="Override chrom.sizes path")
    p.add_argument("--genome-tag", default=None, help="Filename prefix, e.g. GRCh38")
    p.add_argument("--fasta", default=None)
    p.add_argument("--mappability-bw", default=None)
    p.add_argument("--out-dir", default=None, help="Default: <repo>/reference")
    return p.parse_args()


def main():
    args = parse_args()
    repo_root = args.repo_root or os.environ.get("SPACNA_REPO_ROOT") or os.environ.get("AXIS_REPO_ROOT") or os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "..")
    )
    bin_size = parse_bin_size(args.bin_size)
    label = format_bin_label(bin_size)
    genome_tag, map_prefix = species_genome_tag(args.species)
    if args.genome_tag:
        genome_tag = args.genome_tag
        map_prefix = args.genome_tag

    ref_root = args.out_dir or os.path.join(repo_root, "reference")
    bins_dir = os.path.join(ref_root, "genomic_bins")
    gc_dir = os.path.join(ref_root, "gc_content")
    map_dir = os.path.join(ref_root, "mappability")
    chrom_sizes = args.chrom_sizes or os.path.join(
        repo_root, "reference", "chrom_sizes", f"{genome_tag}.chrom.sizes"
    )
    if not os.path.exists(chrom_sizes):
        # try without assuming genome_tag matches file
        alt = os.path.join(repo_root, "reference", "chrom_sizes", f"{genome_tag}.chrom.sizes")
        if os.path.exists(alt):
            chrom_sizes = alt
        else:
            sys.exit(
                f"chrom.sizes not found: {chrom_sizes}\n"
                f"Download / place chromosome sizes, or pass --chrom-sizes."
            )

    bins_txt = os.path.join(bins_dir, f"{genome_tag}_{label}_bins.txt")
    bins_bed = os.path.join(bins_dir, f"{genome_tag}_{label}_bins.bed")
    gc_file = os.path.join(gc_dir, f"{genome_tag}_{label}_gc.txt")
    if args.species.lower() == "human" and label == "1Mb" and map_prefix == "hg38":
        map_file = os.path.join(map_dir, "hg38_1Mb_map.txt")
    else:
        map_file = os.path.join(map_dir, f"{map_prefix}_{label}_map.txt")

    if args.species.lower() == "human":
        fasta = args.fasta or os.environ.get("SPACNA_HUMAN_FASTA", os.environ.get("AXIS_HUMAN_FASTA", ""))
        map_bw = args.mappability_bw or os.environ.get("SPACNA_HUMAN_MAP_BW", os.environ.get("AXIS_HUMAN_MAP_BW", ""))
    else:
        fasta = args.fasta or os.environ.get("SPACNA_MOUSE_FASTA", os.environ.get("AXIS_MOUSE_FASTA", ""))
        map_bw = args.mappability_bw or os.environ.get("SPACNA_MOUSE_MAP_BW", os.environ.get("AXIS_MOUSE_MAP_BW", ""))

    if args.mode in ("bins", "all", "gc", "map"):
        # always ensure bins exist for gc/map
        n = write_bins_from_chrom_sizes(chrom_sizes, bin_size, bins_txt, bins_bed)
        print(f"Wrote {n} bins → {bins_txt}")
        print(f"Wrote BED → {bins_bed}")

    if args.mode in ("gc", "all"):
        if not fasta:
            sys.exit("FASTA required for GC. Pass --fasta or set SPACNA_HUMAN_FASTA / SPACNA_MOUSE_FASTA.")
        calculate_gc_content(fasta, bins_txt, gc_file)

    if args.mode in ("map", "all"):
        if not map_bw:
            sys.exit(
                "Mappability bigWig required. Pass --mappability-bw or set "
                "SPACNA_HUMAN_MAP_BW / SPACNA_MOUSE_MAP_BW."
            )
        calculate_mappability(map_bw, bins_txt, map_file)

    print("Done.")
    print(f"  bins: {bins_txt}")
    if args.mode in ("gc", "all"):
        print(f"  gc:   {gc_file}")
    if args.mode in ("map", "all"):
        print(f"  map:  {map_file}")


if __name__ == "__main__":
    main()
