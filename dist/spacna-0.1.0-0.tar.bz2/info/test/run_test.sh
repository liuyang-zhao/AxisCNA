

set -ex



spacna help
spacna path
test -d "$(spacna path)/scripts"
test -d "$(spacna path)/reference"
python -c "import pysam, natsort, pandas, matplotlib, numpy"
exit 0
