



spacna help
IF %ERRORLEVEL% NEQ 0 exit /B 1
spacna path
IF %ERRORLEVEL% NEQ 0 exit /B 1
test -d "$(spacna path)/scripts"
IF %ERRORLEVEL% NEQ 0 exit /B 1
test -d "$(spacna path)/reference"
IF %ERRORLEVEL% NEQ 0 exit /B 1
python -c "import pysam, natsort, pandas, matplotlib, numpy"
IF %ERRORLEVEL% NEQ 0 exit /B 1
exit /B 0
