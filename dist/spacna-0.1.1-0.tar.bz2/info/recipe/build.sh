#!/usr/bin/env bash
# Install SpaCNA into the Conda prefix.
# Sample barcodes / paper data are NOT included (see data/README.md).
#
# Layout of the built noarch package (what bioconda unpacks from dist/):
#   bin/spacna              # real CLI (174 lines)
#   share/spacna/{scripts,reference,bin,...}
set -euo pipefail

SHARE_DIR="${PREFIX}/share/spacna"
BIN_DIR="${PREFIX}/bin"

mkdir -p "${SHARE_DIR}" "${BIN_DIR}"

copy_tree() {
    local src="$1"
    local dst="$2"
    mkdir -p "${dst}"
    tar -C "${src}" \
        --exclude='.git' \
        --exclude='conda' \
        --exclude='axis-dna-rna' \
        --exclude='results' \
        --exclude='logs' \
        --exclude='tmp' \
        --exclude='rawdata' \
        --exclude='processed' \
        --exclude='tests' \
        --exclude='__pycache__' \
        --exclude='*.pyc' \
        --exclude='build_env_setup.sh' \
        --exclude='conda_build.sh' \
        --exclude='conda_build_config.yaml' \
        --exclude='metadata_conda_debug.yaml' \
        --exclude='Rplots.pdf' \
        --exclude='data/Spatial_DNA' \
        --exclude='data/Spatial_RNA' \
        --exclude='data/samples' \
        --exclude='data/bulk' \
        -cf - . | tar -C "${dst}" -xf -
}

copy_tree "." "${SHARE_DIR}"

mkdir -p "${SHARE_DIR}/data"
if [ -f data/README.md ]; then
    cp -f data/README.md "${SHARE_DIR}/data/README.md"
fi

# Real CLI must land in both PREFIX/bin and share/spacna/bin
# (bioconda build.sh copies package bin/ -> share/spacna/bin and adds thin wrappers).
if ! grep -q 'SpaCNA command-line entry point' bin/spacna; then
    echo "ERROR: bin/spacna is not the real SpaCNA CLI (looks like a thin wrapper)" >&2
    head -10 bin/spacna >&2 || true
    exit 1
fi

install -m 0755 bin/spacna "${BIN_DIR}/spacna"
install -m 0755 bin/axis-dna "${BIN_DIR}/axis-dna"
mkdir -p "${SHARE_DIR}/bin"
install -m 0755 bin/spacna "${SHARE_DIR}/bin/spacna"
install -m 0755 bin/axis-dna "${SHARE_DIR}/bin/axis-dna"
find "${SHARE_DIR}/scripts" -type f \( -name '*.sh' -o -name '*.py' \) -exec chmod +x {} +

cat > "${SHARE_DIR}/conda_env_hint.txt" <<EOF
SpaCNA
Package root: ${SHARE_DIR}
CLI: spacna

Ships 1 Mb bins + GC/mappability only.
Generate any other bin size after downloading FASTA / bigWig:
  spacna gen-reference --species human --bin-size 500kb --mode all \\
    --fasta \$SPACNA_HUMAN_FASTA --mappability-bw \$SPACNA_HUMAN_MAP_BW

Sample barcodes: download from GitHub (data/README.md).

R: source("scripts/R/spacna.R")
  spacna_dna_cnv / spacna_spi / spacna_rna / spacna_gen_reference / spacna_medicc2
EOF
